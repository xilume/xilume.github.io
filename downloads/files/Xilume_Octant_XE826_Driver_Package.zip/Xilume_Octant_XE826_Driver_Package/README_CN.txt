Xilume Octant / XE826 驱动包
发布日期：2026-08-26

Windows
运行 Windows/Xilume_Octant_XE826_Windows_Driver_V7.1.9.0.exe，然后连接设备

Linux
打开 Linux 文件夹并按照 README.md 完成安装

包含版本
Windows 驱动 7.1.9.0
Linux 驱动 1.2.3

技术支持
echen070301@gmail.com
