Xilume Octant / XE826 Driver Package
Release date: 2026-08-26

Windows
Run Windows/Xilume_Octant_XE826_Windows_Driver_V7.1.9.0.exe, then connect the device

Linux
Open the Linux folder and follow README.md

Included versions
Windows driver 7.1.9.0
Linux driver 1.2.3

Support
echen070301@gmail.com
