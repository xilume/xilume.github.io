Xilume XL1326-A Driver Package
Release date: 2026-09-04

Product configuration
Windows exposes two Xilume CAN/CAN FD COM ports
Linux provides two SocketCAN interfaces
XL1326-A does not expose the six serial interfaces

Windows
Run Windows/Xilume_XL1326-A_Windows_Driver_V1.0.0.1.exe, then connect XL1326-A
Windows assigns the actual COM numbers automatically
See Windows/XL1326-A_Device_Manager_Result.png for a Device Manager example

Linux
Open the Linux folder and follow README.md
Version 2.0.2 fixes occasional binding failures after a host reboot or USB re-enumeration

Included versions
Windows driver 1.0.0.1
Linux driver 2.0.2

Support
echen070301@gmail.com
