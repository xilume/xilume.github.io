#!/usr/bin/env bash
set -u

MODULE_NAME="xilume_dualcanfd"
EXPECTED_MODULE_VERSION="2.0.2"
EXPECTED_FIRMWARE_VERSION="7.3.0"
VID="2e3c"
PID="5742"
FAIL=0

pass() { printf '[PASS] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*"; FAIL=1; }
info() { printf '[INFO] %s\n' "$*"; }

printf '%s\n' "Xilume DualCANFD Composite MUX Linux Check"
printf 'Kernel: %s\n' "$(uname -r)"

if command -v lsusb >/dev/null 2>&1; then
    if lsusb -d "${VID}:${PID}" >/dev/null 2>&1; then
        pass "USB device ${VID}:${PID} detected"
        lsusb -d "${VID}:${PID}"
    else
        fail "USB device ${VID}:${PID} not detected"
    fi
else
    info "lsusb is unavailable; USB identity will be checked in sysfs"
fi

if lsmod | awk '{print $1}' | grep -qx "${MODULE_NAME}"; then
    pass "kernel module ${MODULE_NAME} loaded"
else
    fail "${MODULE_NAME} is not loaded (an old xilume_canfd may still be active)"
fi

MODULE_VERSION="$(cat -- "/sys/module/${MODULE_NAME}/version" 2>/dev/null || true)"
if [[ "${MODULE_VERSION}" == "${EXPECTED_MODULE_VERSION}" ]]; then
    pass "module version ${EXPECTED_MODULE_VERSION}"
else
    fail "module version ${MODULE_VERSION:-unknown}; expected ${EXPECTED_MODULE_VERSION} (old driver installed)"
fi

MUX_INTERFACES=()
for INTF_PATH in /sys/bus/usb/devices/*:*; do
    [[ -f "${INTF_PATH}/bInterfaceNumber" ]] || continue
    USB_PARENT="${INTF_PATH%%:*}"
    [[ "$(cat -- "${USB_PARENT}/idVendor" 2>/dev/null || true)" == "${VID}" ]] || continue
    [[ "$(cat -- "${USB_PARENT}/idProduct" 2>/dev/null || true)" == "${PID}" ]] || continue
    [[ "$(cat -- "${INTF_PATH}/bInterfaceNumber" 2>/dev/null || true)" == "04" ]] || continue
    MUX_INTERFACES+=("${INTF_PATH}")
done

if [[ "${#MUX_INTERFACES[@]}" -eq 1 ]]; then
    MUX_PATH="${MUX_INTERFACES[0]}"
    pass "found PID 5742 interface MI_04"
    IF_CLASS="$(cat -- "${MUX_PATH}/bInterfaceClass" 2>/dev/null || true)"
    IF_SUBCLASS="$(cat -- "${MUX_PATH}/bInterfaceSubClass" 2>/dev/null || true)"
    IF_PROTOCOL="$(cat -- "${MUX_PATH}/bInterfaceProtocol" 2>/dev/null || true)"
    if [[ "${IF_CLASS}/${IF_SUBCLASS}/${IF_PROTOCOL}" == "ff/00/00" ]]; then
        pass "MI_04 class/subclass/protocol is ff/00/00"
    else
        fail "MI_04 is ${IF_CLASS:-?}/${IF_SUBCLASS:-?}/${IF_PROTOCOL:-?}; old firmware likely"
    fi

    BOUND_MODULE="$(readlink -f -- "${MUX_PATH}/driver/module" 2>/dev/null || true)"
    if [[ "${BOUND_MODULE}" == "/sys/module/${MODULE_NAME}" ]]; then
        pass "MI_04 bound to ${MODULE_NAME}"
        MUX_BOUND=1
    else
        fail "MI_04 bound module is ${BOUND_MODULE:-none}; expected ${MODULE_NAME}"
        MUX_BOUND=0
    fi

    ENDPOINTS=()
    for EP_PATH in "${MUX_PATH}"/ep_*; do
        [[ -f "${EP_PATH}/bEndpointAddress" ]] || continue
        ENDPOINTS+=("$(cat -- "${EP_PATH}/bEndpointAddress")")
    done
    ENDPOINT_TEXT=" ${ENDPOINTS[*]} "
    if [[ "${ENDPOINT_TEXT}" == *" 05 "* && "${ENDPOINT_TEXT}" == *" 85 "* ]]; then
        pass "MI_04 exposes bulk endpoints 05/85"
    else
        fail "MI_04 endpoints are ${ENDPOINTS[*]:-(none)}; expected 05 and 85"
    fi

    if [[ "${MUX_BOUND}" -eq 1 ]]; then
        HELLO_TOPOLOGY="$(cat -- "${MUX_PATH}/xilume_hello_topology" 2>/dev/null || true)"
        if [[ "${HELLO_TOPOLOGY}" == "2 2 0" ]]; then
            pass "XILUME-MUX-V1 HELLO topology = channels/CAN/serial 2/2/0"
        else
            fail "HELLO topology is ${HELLO_TOPOLOGY:-unavailable}; probe completed without a valid topology"
        fi

        FIRMWARE_VERSION="$(cat -- "${MUX_PATH}/xilume_firmware" 2>/dev/null || true)"
        if [[ "${FIRMWARE_VERSION}" == "${EXPECTED_FIRMWARE_VERSION}" ||
              "${FIRMWARE_VERSION}" == "7.3.1" ]]; then
            pass "firmware ${FIRMWARE_VERSION}"
        else
            fail "firmware ${FIRMWARE_VERSION:-unknown}; expected 7.3.0 or 7.3.1 Composite MUX"
        fi
    else
        info "HELLO topology and firmware version are unavailable because MI_04 probe did not complete"
    fi
elif [[ "${#MUX_INTERFACES[@]}" -eq 0 ]]; then
    fail "PID 5742 MI_04 not found; flash Composite MUX firmware 7.3.0 or 7.3.1"
else
    fail "found ${#MUX_INTERFACES[@]} matching MI_04 interfaces; connect one device for verification"
fi

CAN_NETDEVS=()
CAN1_NETDEVS=()
CAN2_NETDEVS=()
for NET_PATH in /sys/class/net/*; do
    [[ -e "${NET_PATH}/device/driver/module" ]] || continue
    if [[ "$(readlink -f -- "${NET_PATH}/device/driver/module")" == "/sys/module/${MODULE_NAME}" ]]; then
        CAN_NAME="$(basename -- "${NET_PATH}")"
        CAN_PORT="$(cat -- "${NET_PATH}/dev_port" 2>/dev/null || printf '?')"
        CAN_NETDEVS+=("${CAN_NAME}")
        case "${CAN_PORT}" in
            0) CAN1_NETDEVS+=("${CAN_NAME}") ;;
            1) CAN2_NETDEVS+=("${CAN_NAME}") ;;
        esac
    fi
done

if [[ "${#CAN_NETDEVS[@]}" -eq 2 ]]; then
    pass "exactly two SocketCAN interfaces: ${CAN_NETDEVS[*]}"
else
    fail "found ${#CAN_NETDEVS[@]} ${MODULE_NAME} SocketCAN interfaces; expected exactly 2"
fi
[[ "${#CAN1_NETDEVS[@]}" -eq 1 ]] &&
    pass "logical channel 0 / CAN1 -> ${CAN1_NETDEVS[0]}" ||
    fail "logical channel 0 / CAN1 mapping is missing or duplicated"
[[ "${#CAN2_NETDEVS[@]}" -eq 1 ]] &&
    pass "logical channel 1 / CAN2 -> ${CAN2_NETDEVS[0]}" ||
    fail "logical channel 1 / CAN2 mapping is missing or duplicated"

if [[ "${#CAN_NETDEVS[@]}" -gt 0 ]] && command -v ip >/dev/null 2>&1; then
    printf '\nSocketCAN details:\n'
    for CAN_DEV in "${CAN_NETDEVS[@]}"; do
        ip -details link show "${CAN_DEV}" || true
    done
fi

printf '\n'
if [[ "${FAIL}" -eq 0 ]]; then
    printf '%s\n' "All DualCANFD Composite MUX checks passed."
else
    printf '%s\n' "Verification failed. Use the binding and HELLO result above to distinguish module, firmware, and USB transport failures."
    printf '%s\n' "Run: sudo dmesg | grep -i -E 'xilume|can|usb' | tail -100"
fi
exit "${FAIL}"
