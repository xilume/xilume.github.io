#!/usr/bin/env bash
set -u

MODULE_NAME="xilume_8com"
EXPECTED_VERSION="1.2.3"
VID_PID="2e3c:5740"
FAIL=0

printf '%s\n' "Xilume 8HUB Official Linux Driver Check"
printf 'Kernel: %s\n' "$(uname -r)"

if command -v lsusb >/dev/null 2>&1; then
    if lsusb -d "${VID_PID}" >/dev/null 2>&1; then
        printf '%s\n' "[PASS] USB device ${VID_PID} detected"
        lsusb -d "${VID_PID}"
    else
        printf '%s\n' "[FAIL] USB device ${VID_PID} not detected"
        FAIL=1
    fi
else
    printf '%s\n' "[INFO] lsusb is unavailable; skipping USB identity check"
fi

if lsmod | awk '{print $1}' | grep -qx "${MODULE_NAME}"; then
    printf '%s\n' "[PASS] Kernel module ${MODULE_NAME} loaded"
else
    printf '%s\n' "[FAIL] Kernel module ${MODULE_NAME} is not loaded"
    FAIL=1
fi

MODULE_VERSION="$(cat -- "/sys/module/${MODULE_NAME}/version" 2>/dev/null || true)"
if command -v modinfo >/dev/null 2>&1; then
    MODULE_FILE="$(modinfo -n "${MODULE_NAME}" 2>/dev/null || true)"
    [[ -n "${MODULE_FILE}" ]] && printf 'Module: %s\n' "${MODULE_FILE}"
fi
[[ -n "${MODULE_VERSION}" ]] && printf 'Loaded version: %s\n' "${MODULE_VERSION}"
if [[ "${MODULE_VERSION}" == "${EXPECTED_VERSION}" ]]; then
    printf '[PASS] Loaded module version is %s\n' "${EXPECTED_VERSION}"
else
    printf '[FAIL] Loaded module version is %s; expected %s\n' \
        "${MODULE_VERSION:-unknown}" "${EXPECTED_VERSION}"
    FAIL=1
fi

shopt -s nullglob
TTY_NODES=(/dev/ttyXilume*)
if [[ "${#TTY_NODES[@]}" -ge 6 ]]; then
    printf '[PASS] Found %d Xilume serial TTY nodes\n' \
        "${#TTY_NODES[@]}"
else
    printf '[FAIL] Found %d ttyXilume nodes; expected at least 6\n' \
        "${#TTY_NODES[@]}"
    FAIL=1
fi

for SERIAL_INDEX in 1 2 3 4 5 6; do
    SERIAL_ALIAS="/dev/xilume/serial${SERIAL_INDEX}"
    if [[ -L "${SERIAL_ALIAS}" && -e "${SERIAL_ALIAS}" ]]; then
        printf '[PASS] serial%d: %s -> %s\n' \
            "${SERIAL_INDEX}" "${SERIAL_ALIAS}" \
            "$(readlink -- "${SERIAL_ALIAS}")"
    else
        printf '[FAIL] serial%d alias is missing: %s\n' \
            "${SERIAL_INDEX}" "${SERIAL_ALIAS}"
        FAIL=1
    fi
done

CAN_NETDEVS=()
CAN1_NETDEVS=()
CAN2_NETDEVS=()
for NET_PATH in /sys/class/net/*; do
    [[ -e "${NET_PATH}/device/driver/module" ]] || continue
    if [[ "$(readlink -f -- "${NET_PATH}/device/driver/module")" == "/sys/module/${MODULE_NAME}" ]]; then
        CAN_NAME="$(basename -- "${NET_PATH}")"
        CAN_PORT="$(cat -- "${NET_PATH}/dev_port" 2>/dev/null || printf '?')"
        CAN_NETDEVS+=("${CAN_NAME}")
        case "${CAN_PORT}" in
            0) CAN1_NETDEVS+=("${CAN_NAME}") ;;
            1) CAN2_NETDEVS+=("${CAN_NAME}") ;;
        esac
    fi
done

printf 'Xilume SocketCAN interfaces found: %s\n' \
    "${CAN_NETDEVS[*]:-(none)}"
if [[ "${#CAN1_NETDEVS[@]}" -gt 0 ]]; then
    printf '[PASS] Xilume CAN1 -> %s\n' "${CAN1_NETDEVS[*]}"
else
    printf '%s\n' '[FAIL] Xilume CAN1 was not found'
    FAIL=1
fi
if [[ "${#CAN2_NETDEVS[@]}" -gt 0 ]]; then
    printf '[PASS] Xilume CAN2 -> %s\n' "${CAN2_NETDEVS[*]}"
else
    printf '%s\n' '[FAIL] Xilume CAN2 was not found'
    FAIL=1
fi

printf '%s\n' ""
printf '%s\n' "Serial port map:"
for SYS_TTY in /sys/class/tty/ttyXilume*; do
    NAME="$(basename -- "${SYS_TTY}")"
    ROLE="$(cat -- "${SYS_TTY}/xilume_role" 2>/dev/null || printf '?')"
    FW="$(cat -- "${SYS_TTY}/xilume_firmware" 2>/dev/null || printf '?')"
    STATS="$(cat -- "${SYS_TTY}/xilume_stats" 2>/dev/null || printf '?')"
    printf '  /dev/%-12s  %-8s  FW=%s  %s\n' \
        "${NAME}" "${ROLE}" "${FW}" "${STATS}"
done

if command -v ip >/dev/null 2>&1 &&
   [[ "${#CAN_NETDEVS[@]}" -gt 0 ]]; then
    printf '%s\n' ""
    printf '%s\n' "SocketCAN details:"
    for CAN_DEV in "${CAN_NETDEVS[@]}"; do
        ip -details link show "${CAN_DEV}" || true
    done
fi

if [[ -d /dev/xilume ]]; then
    printf '%s\n' ""
    printf '%s\n' "Stable aliases:"
    find /dev/xilume -maxdepth 1 -type l -printf '  %p -> %l\n' \
        2>/dev/null | sort
fi

printf '%s\n' ""
if [[ "${FAIL}" -eq 0 ]]; then
    printf '%s\n' "All driver checks passed."
else
    printf '%s\n' "One or more checks failed."
    printf '%s\n' "Recent kernel messages:"
    if command -v journalctl >/dev/null 2>&1; then
        journalctl -k -n 100 --no-pager 2>/dev/null |
            grep -i -E 'xilume|can|usb|module|secure' | tail -60
    else
        dmesg 2>/dev/null |
            grep -i -E 'xilume|can|usb|module|secure' | tail -60
    fi
fi

exit "${FAIL}"
