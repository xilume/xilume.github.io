#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_NAME="xilume-8com"
MODULE_NAME="xilume_8com"
KERNEL_VERSION="$(uname -r)"
UDEV_RULE="/etc/udev/rules.d/99-xilume-8com.rules"
DIRECT_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/updates/xilume"
DIRECT_MODULE="${DIRECT_MODULE_DIR}/${MODULE_NAME}.ko"
STALE_DKMS_MODULE="/lib/modules/${KERNEL_VERSION}/updates/dkms/${MODULE_NAME}.ko"

die() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

remove_registered_version() {
    local version="$1"

    if command -v dkms >/dev/null 2>&1 &&
       dkms status -m "${PACKAGE_NAME}" -v "${version}" 2>/dev/null |
       grep -q .; then
        dkms remove -m "${PACKAGE_NAME}" -v "${version}" --all
    fi
}

if [[ "${EUID}" -ne 0 ]]; then
    command -v sudo >/dev/null 2>&1 ||
        die "Run this uninstaller as root or install sudo."
    exec sudo bash "$0" "$@"
fi

if lsmod | awk '{print $1}' | grep -qx "${MODULE_NAME}"; then
    if command -v ip >/dev/null 2>&1; then
        for NET_PATH in /sys/class/net/*; do
            [[ -e "${NET_PATH}/device/driver/module" ]] || continue
            if [[ "$(readlink -f -- "${NET_PATH}/device/driver/module")" == "/sys/module/${MODULE_NAME}" ]]; then
                ip link set dev "$(basename -- "${NET_PATH}")" down || true
            fi
        done
    fi
    modprobe -r "${MODULE_NAME}" ||
        die "Close ttyXilume ports, bring CAN interfaces down, unplug the Hub, and try again."
fi

remove_registered_version "1.0.0"
remove_registered_version "1.1.0"
remove_registered_version "1.1.1"
remove_registered_version "1.2.0"
remove_registered_version "1.2.1"
remove_registered_version "1.2.2"
remove_registered_version "1.2.3"

rm -f -- "${DIRECT_MODULE}" "${DIRECT_MODULE}.xz" \
    "${DIRECT_MODULE}.gz" "${DIRECT_MODULE}.zst" \
    "${STALE_DKMS_MODULE}" "${STALE_DKMS_MODULE}.xz" \
    "${STALE_DKMS_MODULE}.gz" "${STALE_DKMS_MODULE}.zst"
rm -f -- "${UDEV_RULE}"
rm -rf -- "/usr/src/${PACKAGE_NAME}-1.0.0" \
    "/usr/src/${PACKAGE_NAME}-1.1.0" \
    "/usr/src/${PACKAGE_NAME}-1.1.1" \
    "/usr/src/${PACKAGE_NAME}-1.2.0" \
    "/usr/src/${PACKAGE_NAME}-1.2.1" \
    "/usr/src/${PACKAGE_NAME}-1.2.2" \
    "/usr/src/${PACKAGE_NAME}-1.2.3"
rmdir --ignore-fail-on-non-empty -- "${DIRECT_MODULE_DIR}" \
    2>/dev/null || true

depmod -a "${KERNEL_VERSION}"
if command -v udevadm >/dev/null 2>&1; then
    udevadm control --reload-rules
fi

printf '%s\n' "Xilume 8HUB Linux driver removed."
printf '%s\n' "The local Secure Boot key was retained for safety."
