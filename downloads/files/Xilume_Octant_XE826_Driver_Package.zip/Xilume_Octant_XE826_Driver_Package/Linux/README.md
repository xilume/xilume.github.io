# Xilume Octant / XE826 Linux Driver

Version 1.2.3

## System requirements

- Linux kernel 5.4 or later
- DKMS, compiler toolchain, and kernel headers
- x86-64 or aarch64 system

## Install

```bash
chmod +x install.sh uninstall.sh verify.sh
sudo ./install.sh
```

Reconnect the device after installation, then check the interfaces:

```bash
./verify.sh
```

The driver provides two SocketCAN interfaces and six stable serial paths at
`/dev/xilume/serial1` through `/dev/xilume/serial6`

## Remove

```bash
sudo ./uninstall.sh
```

## Support

Email echen070301@gmail.com with the product model and Linux version

---

# Xilume Octant / XE826 Linux 驱动

版本 1.2.3

## 系统要求

- Linux 5.4 或更新内核
- DKMS、编译工具与当前内核头文件
- x86-64 或 aarch64 系统

## 安装

```bash
chmod +x install.sh uninstall.sh verify.sh
sudo ./install.sh
```

安装完成后重新连接设备，再检查接口：

```bash
./verify.sh
```

驱动提供两路 SocketCAN 接口，以及 `/dev/xilume/serial1` 至
`/dev/xilume/serial6` 六个稳定串行路径

## 卸载

```bash
sudo ./uninstall.sh
```

## 技术支持

请将产品型号与 Linux 版本发送至 echen070301@gmail.com
