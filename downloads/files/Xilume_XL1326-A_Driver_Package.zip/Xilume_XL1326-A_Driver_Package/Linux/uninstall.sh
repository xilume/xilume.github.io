#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_NAME="xilume-dualcanfd"
MODULE_NAME="xilume_dualcanfd"
KERNEL_VERSION="$(uname -r)"
DIRECT_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/updates/xilume"
DIRECT_MODULE="${DIRECT_MODULE_DIR}/${MODULE_NAME}.ko"
STALE_DKMS_MODULE="/lib/modules/${KERNEL_VERSION}/updates/dkms/${MODULE_NAME}.ko"

die() { printf 'Error: %s\n' "$*" >&2; exit 1; }

if [[ "${EUID}" -ne 0 ]]; then
    command -v sudo >/dev/null 2>&1 || die "Run as root or install sudo."
    exec sudo bash "$0" "$@"
fi

if lsmod | awk '{print $1}' | grep -qx "${MODULE_NAME}"; then
    if command -v ip >/dev/null 2>&1; then
        for NET_PATH in /sys/class/net/*; do
            [[ -e "${NET_PATH}/device/driver/module" ]] || continue
            if [[ "$(readlink -f -- "${NET_PATH}/device/driver/module")" == "/sys/module/${MODULE_NAME}" ]]; then
                ip link set dev "$(basename -- "${NET_PATH}")" down || true
            fi
        done
    fi
    modprobe -r "${MODULE_NAME}" ||
        die "Unplug XL1326-A, close CAN users, and retry."
fi

if command -v dkms >/dev/null 2>&1; then
    while IFS= read -r VERSION; do
        [[ -n "${VERSION}" ]] || continue
        dkms remove -m "${PACKAGE_NAME}" -v "${VERSION}" --all || true
        rm -rf -- "/usr/src/${PACKAGE_NAME}-${VERSION}"
    done < <(
        dkms status -m "${PACKAGE_NAME}" 2>/dev/null |
        sed -n "s#^${PACKAGE_NAME}/\([^,[:space:]]*\).*#\1#p" |
        sort -u
    )
fi

rm -f -- "${DIRECT_MODULE}" "${DIRECT_MODULE}.xz" \
    "${DIRECT_MODULE}.gz" "${DIRECT_MODULE}.zst" \
    "${STALE_DKMS_MODULE}" "${STALE_DKMS_MODULE}.xz" \
    "${STALE_DKMS_MODULE}.gz" "${STALE_DKMS_MODULE}.zst"
rmdir --ignore-fail-on-non-empty -- "${DIRECT_MODULE_DIR}" 2>/dev/null || true
depmod -a "${KERNEL_VERSION}"

printf '%s\n' "Xilume XL1326-A Linux driver removed."
printf '%s\n' "The shared xilume_8com driver was not touched."
printf '%s\n' "The local Secure Boot key was retained for safety."
