// SPDX-License-Identifier: GPL-2.0-only
/*
 * Xilume XL1326-A XILUME-MUX-V1 SocketCAN driver
 *
 * Firmware contract: XILUME-MUX-V1, DualCANFD Composite MUX V7.3.0
 * USB: VID 0x2e3c, PID 0x5742, interface ff/00/00,
 *      bulk OUT 0x05, bulk IN 0x85
 *
 * Logical channels:
 *   0  CAN FD 1 translated to SocketCAN
 *   1  CAN FD 2 translated to SocketCAN
 */

#include <linux/can.h>
#include <linux/can/dev.h>
#include <linux/completion.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/kref.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/netdevice.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/usb.h>
#include <linux/version.h>
#include <linux/workqueue.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
#include <linux/can/length.h>
#include <linux/can/skb.h>
#endif

#define XILUME_DRIVER_NAME             "xilume_dualcanfd"
#define XILUME_DRIVER_VERSION          "2.0.1"

#define XILUME_USB_VID                 0x2e3c
#define XILUME_USB_PID                 0x5742
#define XILUME_USB_INTERFACE           4
#define XILUME_USB_EP_OUT              0x05
#define XILUME_USB_EP_IN               0x85

#define XILUME_PROTOCOL_VERSION        1
#define XILUME_CHANNEL_COUNT           2
#define XILUME_CAN_COUNT               2
#define XILUME_MAX_PAYLOAD             56
#define XILUME_FRAME_HEADER_SIZE       8
#define XILUME_USB_PACKET_SIZE         64
#define XILUME_RX_URB_COUNT            4

#define XILUME_USB_TIMEOUT_MS          1000
#define XILUME_ACK_TIMEOUT_MS          1000
#define XILUME_HELLO_TIMEOUT_MS        1500
#define XILUME_CAN_RESPONSE_TIMEOUT_MS 2000

#define XILUME_CAN_CLOCK_HZ            160000000U
#define XILUME_CAN_LINE_SIZE           320

#define XILUME_MAGIC_0                 0x58
#define XILUME_MAGIC_1                 0x4c

#define XILUME_FRAME_DATA              0x01
#define XILUME_FRAME_HELLO             0x7e
#define XILUME_FRAME_ACK               0x80
#define XILUME_FRAME_ERROR             0xff

struct xilume_frame_header {
	u8 magic0;
	u8 magic1;
	u8 version;
	u8 channel;
	u8 type;
	u8 flags;
	__le16 length;
} __packed;

struct xilume_device;

enum xilume_can_response_kind {
	XILUME_CAN_RESPONSE_NONE = 0,
	XILUME_CAN_RESPONSE_TIMING,
	XILUME_CAN_RESPONSE_RESET,
	XILUME_CAN_RESPONSE_TX,
	XILUME_CAN_RESPONSE_TXFD,
};

struct xilume_can {
	struct can_priv can;
	struct net_device *netdev;
	struct xilume_device *xdev;
	unsigned int channel;

	spinlock_t rx_lock;
	char rx_line[XILUME_CAN_LINE_SIZE];
	size_t rx_length;
	bool rx_overflow;

	struct mutex request_mutex;
	spinlock_t response_lock;
	struct completion response_done;
	enum xilume_can_response_kind response_kind;
	bool response_pending;
	int response_result;

	spinlock_t tx_lock;
	struct work_struct tx_work;
	bool tx_pending;
	char tx_line[XILUME_CAN_LINE_SIZE];
	size_t tx_length;

	struct can_berr_counter bec;
	atomic64_t protocol_errors;
};

struct xilume_rx_slot {
	struct xilume_device *xdev;
	struct urb *urb;
	u8 *buffer;
};

struct xilume_device {
	struct kref kref;
	struct usb_device *udev;
	struct usb_interface *interface;
	u8 bulk_in;
	u8 bulk_out;
	bool disconnected;
	u8 *tx_buffer;

	struct usb_anchor rx_anchor;
	struct xilume_rx_slot rx[XILUME_RX_URB_COUNT];

	struct mutex tx_mutex;
	spinlock_t ack_lock;
	struct completion ack_done;
	bool ack_pending;
	u8 ack_channel;
	u8 ack_request_type;
	u8 ack_status;
	u8 ack_error;
	u16 ack_transferred;

	struct completion hello_done;
	bool hello_valid;
	u8 firmware_major;
	u8 firmware_minor;
	u8 firmware_patch;
	bool firmware_attr_created;
	bool topology_attr_created;

	struct xilume_can *cans[XILUME_CAN_COUNT];

	atomic64_t rx_frames;
	atomic64_t rx_protocol_errors;
	atomic64_t usb_errors;
};

static const struct can_bittiming_const xilume_nominal_bittiming_const = {
	.name = XILUME_DRIVER_NAME,
	.tseg1_min = 1,
	.tseg1_max = 512,
	.tseg2_min = 1,
	.tseg2_max = 128,
	.sjw_max = 128,
	.brp_min = 1,
	.brp_max = 32,
	.brp_inc = 1,
};

static const struct can_bittiming_const xilume_data_bittiming_const = {
	.name = XILUME_DRIVER_NAME,
	.tseg1_min = 1,
	.tseg1_max = 256,
	.tseg2_min = 1,
	.tseg2_max = 128,
	.sjw_max = 128,
	.brp_min = 1,
	.brp_max = 32,
	.brp_inc = 1,
};

static void xilume_device_release(struct kref *kref)
{
	struct xilume_device *xdev =
		container_of(kref, struct xilume_device, kref);

	kfree(xdev->tx_buffer);
	usb_put_dev(xdev->udev);
	kfree(xdev);
}

static int xilume_send_frame(struct xilume_device *xdev, u8 channel,
			     u8 type, const void *payload, size_t length,
			     bool wait_for_ack, u16 *acknowledged)
{
	u8 *frame;
	struct xilume_frame_header *header;
	unsigned long flags;
	unsigned long waited;
	int actual = 0;
	int ret;
	u8 ack_status;
	u8 ack_error;
	u16 ack_transferred;

	if (acknowledged)
		*acknowledged = 0;
	if (length > XILUME_MAX_PAYLOAD || (length && !payload))
		return -EMSGSIZE;

	mutex_lock(&xdev->tx_mutex);
	if (READ_ONCE(xdev->disconnected)) {
		ret = -ENODEV;
		goto out_unlock;
	}

	/*
	 * usb_bulk_msg() may DMA-map the transfer buffer. Kernel stack memory
	 * is not a valid DMA source on all xHCI systems, so use the device's
	 * kmalloc-backed buffer while tx_mutex serializes all OUT transfers.
	 */
	frame = xdev->tx_buffer;
	if (!frame) {
		ret = -ENODEV;
		goto out_unlock;
	}
	header = (struct xilume_frame_header *)frame;
	header->magic0 = XILUME_MAGIC_0;
	header->magic1 = XILUME_MAGIC_1;
	header->version = XILUME_PROTOCOL_VERSION;
	header->channel = channel;
	header->type = type;
	header->flags = 0;
	header->length = cpu_to_le16((u16)length);
	if (length)
		memcpy(frame + sizeof(*header), payload, length);

	if (wait_for_ack) {
		spin_lock_irqsave(&xdev->ack_lock, flags);
		reinit_completion(&xdev->ack_done);
		xdev->ack_channel = channel;
		xdev->ack_request_type = type;
		xdev->ack_status = 0xff;
		xdev->ack_error = 0;
		xdev->ack_transferred = 0;
		xdev->ack_pending = true;
		spin_unlock_irqrestore(&xdev->ack_lock, flags);
	}

	ret = usb_bulk_msg(xdev->udev,
			   usb_sndbulkpipe(xdev->udev, xdev->bulk_out),
			   frame, sizeof(*header) + length, &actual,
			   XILUME_USB_TIMEOUT_MS);
	if (ret)
		goto cancel_ack;
	if (actual != sizeof(*header) + length) {
		ret = -EIO;
		goto cancel_ack;
	}

	if (!wait_for_ack) {
		if (acknowledged)
			*acknowledged = (u16)length;
		ret = 0;
		goto out_unlock;
	}

	waited = wait_for_completion_timeout(
		&xdev->ack_done, msecs_to_jiffies(XILUME_ACK_TIMEOUT_MS));

	spin_lock_irqsave(&xdev->ack_lock, flags);
	xdev->ack_pending = false;
	ack_status = xdev->ack_status;
	ack_error = xdev->ack_error;
	ack_transferred = xdev->ack_transferred;
	spin_unlock_irqrestore(&xdev->ack_lock, flags);

	if (!waited) {
		ret = -ETIMEDOUT;
		goto out_unlock;
	}
	if (READ_ONCE(xdev->disconnected)) {
		ret = -ENODEV;
		goto out_unlock;
	}
	if (ack_error || (ack_status != 0 && ack_status != 2)) {
		ret = -EPROTO;
		goto out_unlock;
	}
	if (ack_transferred > length) {
		ret = -EPROTO;
		goto out_unlock;
	}

	if (acknowledged)
		*acknowledged = ack_transferred;
	ret = 0;
	goto out_unlock;

cancel_ack:
	if (wait_for_ack) {
		spin_lock_irqsave(&xdev->ack_lock, flags);
		xdev->ack_pending = false;
		spin_unlock_irqrestore(&xdev->ack_lock, flags);
	}
out_unlock:
	if (ret)
		atomic64_inc(&xdev->usb_errors);
	mutex_unlock(&xdev->tx_mutex);
	return ret;
}

static int xilume_send_can_text(struct xilume_can *xcan,
				const char *text, size_t length)
{
	size_t offset = 0;
	int ret;

	if (!length || length >= XILUME_CAN_LINE_SIZE)
		return -EMSGSIZE;

	while (offset < length) {
		size_t chunk = min_t(size_t, length - offset,
				     XILUME_MAX_PAYLOAD);

		ret = xilume_send_frame(
			xcan->xdev, (u8)xcan->channel, XILUME_FRAME_DATA,
			text + offset, chunk, false, NULL);
		if (ret)
			return ret;
		offset += chunk;
	}

	return 0;
}

static bool xilume_can_response_matches(
	enum xilume_can_response_kind kind, const char *line)
{
	if (!strncmp(line, "ERR ", 4))
		return true;

	switch (kind) {
	case XILUME_CAN_RESPONSE_TIMING:
		return !strncmp(line, "OK TIMING ", 10);
	case XILUME_CAN_RESPONSE_RESET:
		return !strncmp(line, "OK RESET_CAN ", 13);
	case XILUME_CAN_RESPONSE_TX:
		return !strncmp(line, "OK TX_DONE ", 11);
	case XILUME_CAN_RESPONSE_TXFD:
		return !strncmp(line, "OK TXFD_DONE ", 13);
	default:
		return false;
	}
}

static int xilume_can_request(struct xilume_can *xcan,
			      enum xilume_can_response_kind kind,
			      const char *text, size_t length)
{
	unsigned long flags;
	unsigned long waited;
	int ret;

	mutex_lock(&xcan->request_mutex);
	if (READ_ONCE(xcan->xdev->disconnected)) {
		ret = -ENODEV;
		goto out_unlock;
	}

	reinit_completion(&xcan->response_done);
	spin_lock_irqsave(&xcan->response_lock, flags);
	xcan->response_kind = kind;
	xcan->response_result = -ETIMEDOUT;
	xcan->response_pending = true;
	spin_unlock_irqrestore(&xcan->response_lock, flags);

	ret = xilume_send_can_text(xcan, text, length);
	if (ret)
		goto out_cancel;

	waited = wait_for_completion_timeout(
		&xcan->response_done,
		msecs_to_jiffies(XILUME_CAN_RESPONSE_TIMEOUT_MS));

	spin_lock_irqsave(&xcan->response_lock, flags);
	xcan->response_pending = false;
	ret = waited ? xcan->response_result : -ETIMEDOUT;
	spin_unlock_irqrestore(&xcan->response_lock, flags);
	goto out_unlock;

out_cancel:
	spin_lock_irqsave(&xcan->response_lock, flags);
	xcan->response_pending = false;
	spin_unlock_irqrestore(&xcan->response_lock, flags);
out_unlock:
	mutex_unlock(&xcan->request_mutex);
	return ret;
}

static void xilume_can_abort_request(struct xilume_can *xcan, int error)
{
	unsigned long flags;
	bool wake = false;

	spin_lock_irqsave(&xcan->response_lock, flags);
	if (xcan->response_pending) {
		xcan->response_pending = false;
		xcan->response_result = error;
		wake = true;
	}
	spin_unlock_irqrestore(&xcan->response_lock, flags);

	if (wake)
		complete(&xcan->response_done);
}

static void xilume_can_update_diagnostics(struct xilume_can *xcan,
					  const char *line)
{
	const char *field;
	unsigned int value;

	field = strstr(line, "TEC=");
	if (field && sscanf(field + 4, "%u", &value) == 1)
		xcan->bec.txerr = min(value, 255U);

	field = strstr(line, "REC=");
	if (field && sscanf(field + 4, "%u", &value) == 1)
		xcan->bec.rxerr = min(value, 255U);

	field = strstr(line, "BUSOFF=");
	if (field && sscanf(field + 7, "%u", &value) == 1 && value &&
	    xcan->can.state != CAN_STATE_BUS_OFF) {
		xcan->can.state = CAN_STATE_BUS_OFF;
		if (netif_running(xcan->netdev))
			can_bus_off(xcan->netdev);
	}
}

static int xilume_can_tokenize(char *line, char **tokens, int maximum)
{
	char *cursor = line;
	char *token;
	int count = 0;

	while ((token = strsep(&cursor, " \t")) != NULL) {
		if (!*token)
			continue;
		if (count >= maximum)
			return -E2BIG;
		tokens[count++] = token;
	}

	return count;
}

static void xilume_can_bad_rx_line(struct xilume_can *xcan)
{
	xcan->netdev->stats.rx_errors++;
	xcan->netdev->stats.rx_dropped++;
	atomic64_inc(&xcan->protocol_errors);
}

static void xilume_can_receive_line(struct xilume_can *xcan, char *line)
{
	char *tokens[72];
	struct net_device *netdev = xcan->netdev;
	struct sk_buff *skb;
	struct can_frame *cf;
	struct canfd_frame *cfd;
	u8 data[CANFD_MAX_DLEN];
	u32 identifier;
	unsigned int length;
	bool is_fd;
	bool brs = false;
	int first_data;
	int token_count;
	unsigned int i;

	token_count = xilume_can_tokenize(line, tokens, ARRAY_SIZE(tokens));
	if (token_count < 3) {
		xilume_can_bad_rx_line(xcan);
		return;
	}

	is_fd = !strcmp(tokens[0], "RXFD");
	if (is_fd) {
		const char *expected_channel =
			xcan->channel == 0 ? "CAN1" : "CAN2";

		if (token_count < 5 ||
		    strcmp(tokens[1], expected_channel) ||
		    kstrtou32(tokens[2], 0, &identifier) ||
		    kstrtouint(tokens[3], 10, &length) ||
		    length > CANFD_MAX_DLEN) {
			xilume_can_bad_rx_line(xcan);
			return;
		}
		if (!strcmp(tokens[4], "BRS"))
			brs = true;
		else if (strcmp(tokens[4], "NOBRS")) {
			xilume_can_bad_rx_line(xcan);
			return;
		}
		first_data = 5;
	} else {
		const char *expected_prefix =
			xcan->channel == 0 ? "RX" : "RX2";

		if (strcmp(tokens[0], expected_prefix) ||
		    kstrtou32(tokens[1], 0, &identifier) ||
		    kstrtouint(tokens[2], 10, &length) ||
		    length > CAN_MAX_DLEN) {
			xilume_can_bad_rx_line(xcan);
			return;
		}
		first_data = 3;
	}

	if (identifier > CAN_EFF_MASK ||
	    token_count != first_data + (int)length) {
		xilume_can_bad_rx_line(xcan);
		return;
	}

	for (i = 0; i < length; i++) {
		if (kstrtou8(tokens[first_data + i], 16, &data[i])) {
			xilume_can_bad_rx_line(xcan);
			return;
		}
	}

	if (!netif_running(netdev))
		return;

	if (is_fd) {
		skb = alloc_canfd_skb(netdev, &cfd);
		if (!skb) {
			netdev->stats.rx_dropped++;
			return;
		}
		cfd->can_id = identifier > CAN_SFF_MASK ?
			(identifier | CAN_EFF_FLAG) : identifier;
		cfd->len = (u8)length;
		cfd->flags = brs ? CANFD_BRS : 0;
		memcpy(cfd->data, data, length);
	} else {
		skb = alloc_can_skb(netdev, &cf);
		if (!skb) {
			netdev->stats.rx_dropped++;
			return;
		}
		cf->can_id = identifier > CAN_SFF_MASK ?
			(identifier | CAN_EFF_FLAG) : identifier;
		cf->can_dlc = (u8)length;
		memcpy(cf->data, data, length);
	}

	netdev->stats.rx_packets++;
	netdev->stats.rx_bytes += length;
	netif_rx(skb);
}

static void xilume_can_process_line(struct xilume_can *xcan, char *line)
{
	unsigned long flags;
	bool complete_waiter = false;

	if (!strncmp(line, "RX ", 3) ||
	    !strncmp(line, "RX2 ", 4) ||
	    !strncmp(line, "RXFD ", 5)) {
		xilume_can_receive_line(xcan, line);
		return;
	}

	xilume_can_update_diagnostics(xcan, line);
	if (!strncmp(line, "ERR ", 4))
		dev_warn_ratelimited(
			&xcan->netdev->dev,
			"firmware response: %s\n", line);

	spin_lock_irqsave(&xcan->response_lock, flags);
	if (xcan->response_pending &&
	    xilume_can_response_matches(xcan->response_kind, line)) {
		xcan->response_result =
			strncmp(line, "ERR ", 4) ? 0 : -EIO;
		complete_waiter = true;
	}
	spin_unlock_irqrestore(&xcan->response_lock, flags);

	if (complete_waiter)
		complete(&xcan->response_done);
}

static void xilume_can_feed_stream(struct xilume_can *xcan,
				   const u8 *payload, size_t length)
{
	unsigned long flags;
	char complete_line[XILUME_CAN_LINE_SIZE];
	size_t i;

	spin_lock_irqsave(&xcan->rx_lock, flags);
	for (i = 0; i < length; i++) {
		char character = payload[i];
		size_t line_length;

		if (character == '\r' || character == '\n') {
			if (!xcan->rx_length) {
				xcan->rx_overflow = false;
				continue;
			}

			if (xcan->rx_overflow) {
				xcan->rx_length = 0;
				xcan->rx_overflow = false;
				atomic64_inc(&xcan->protocol_errors);
				continue;
			}

			line_length = xcan->rx_length;
			memcpy(complete_line, xcan->rx_line, line_length);
			complete_line[line_length] = '\0';
			xcan->rx_length = 0;

			spin_unlock_irqrestore(&xcan->rx_lock, flags);
			xilume_can_process_line(xcan, complete_line);
			spin_lock_irqsave(&xcan->rx_lock, flags);
			continue;
		}

		if (xcan->rx_overflow)
			continue;
		if (xcan->rx_length >= XILUME_CAN_LINE_SIZE - 1) {
			xcan->rx_overflow = true;
			continue;
		}
		xcan->rx_line[xcan->rx_length++] = character;
	}
	spin_unlock_irqrestore(&xcan->rx_lock, flags);
}

static void xilume_can_finish_echo(struct xilume_can *xcan, bool success)
{
	struct net_device *netdev = xcan->netdev;
	unsigned long flags;
	bool pending;
	unsigned int payload_length = 0;

	spin_lock_irqsave(&xcan->tx_lock, flags);
	pending = xcan->tx_pending;
	xcan->tx_pending = false;
	spin_unlock_irqrestore(&xcan->tx_lock, flags);

	if (!pending)
		return;

	if (success) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
		payload_length = can_get_echo_skb(netdev, 0, NULL);
#else
		payload_length = can_get_echo_skb(netdev, 0);
#endif
		netdev->stats.tx_packets++;
		netdev->stats.tx_bytes += payload_length;
	} else {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 13, 0)
		can_free_echo_skb(netdev, 0, NULL);
#else
		can_free_echo_skb(netdev, 0);
#endif
		netdev->stats.tx_errors++;
	}

	if (netif_running(netdev) &&
	    xcan->can.state != CAN_STATE_STOPPED &&
	    xcan->can.state != CAN_STATE_BUS_OFF)
		netif_wake_queue(netdev);
}

static void xilume_can_tx_worker(struct work_struct *work)
{
	struct xilume_can *xcan =
		container_of(work, struct xilume_can, tx_work);
	enum xilume_can_response_kind kind;
	int ret;

	kind = !strncmp(xcan->tx_line, "TXFD ", 5) ?
		XILUME_CAN_RESPONSE_TXFD : XILUME_CAN_RESPONSE_TX;
	ret = xilume_can_request(
		xcan, kind, xcan->tx_line, xcan->tx_length);
	if (ret && ret != -ENODEV && ret != -ECANCELED)
		dev_warn_ratelimited(
			&xcan->netdev->dev,
			"firmware rejected or timed out CAN%u TX: %d\n",
			xcan->channel + 1, ret);

	xilume_can_finish_echo(xcan, ret == 0);
}

static netdev_tx_t xilume_can_start_xmit(struct sk_buff *skb,
					 struct net_device *netdev)
{
	struct xilume_can *xcan = netdev_priv(netdev);
	struct canfd_frame *cfd =
		(struct canfd_frame *)skb->data;
	struct can_frame *cf =
		(struct can_frame *)skb->data;
	u8 *data;
	unsigned long flags;
	canid_t can_id;
	unsigned int length;
	size_t used;
	bool is_fd;
	unsigned int i;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	unsigned int frame_length;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
	int ret;
#endif

	if (can_dropped_invalid_skb(netdev, skb))
		return NETDEV_TX_OK;

	is_fd = skb->len == CANFD_MTU;
	can_id = is_fd ? cfd->can_id : cf->can_id;
	length = is_fd ? cfd->len : cf->can_dlc;
	data = is_fd ? cfd->data : cf->data;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	if (is_fd) {
		unsigned int wire_length =
			can_fd_dlc2len(can_fd_len2dlc(length));

		if (wire_length > length)
			memset(data + length, 0, wire_length - length);
		length = wire_length;
		cfd->len = wire_length;
	}
#endif

	/*
	 * The inherited V7.2.1 CAN text contract has no RTR token and infers EFF from
	 * an identifier above 0x7ff. Reject forms that cannot be represented
	 * instead of silently putting a different frame on the bus.
	 */
	if ((!is_fd && (can_id & CAN_RTR_FLAG)) ||
	    ((can_id & CAN_EFF_FLAG) &&
	     ((can_id & CAN_EFF_MASK) <= CAN_SFF_MASK))) {
		dev_warn_ratelimited(
			&netdev->dev,
			"frame cannot be represented by Composite MUX 7.3.0 text protocol\n");
		netdev->stats.tx_dropped++;
		dev_kfree_skb(skb);
		return NETDEV_TX_OK;
	}

	spin_lock_irqsave(&xcan->tx_lock, flags);
	if (xcan->tx_pending) {
		spin_unlock_irqrestore(&xcan->tx_lock, flags);
		return NETDEV_TX_BUSY;
	}
	xcan->tx_pending = true;
	spin_unlock_irqrestore(&xcan->tx_lock, flags);

	if (is_fd) {
		used = scnprintf(
			xcan->tx_line, sizeof(xcan->tx_line),
			"TXFD CAN%u 0x%X %u %s",
			xcan->channel + 1,
			can_id & CAN_EFF_MASK, length,
			(cfd->flags & CANFD_BRS) ? "BRS" : "NOBRS");
	} else {
		used = scnprintf(
			xcan->tx_line, sizeof(xcan->tx_line),
			"TX 0x%X %u",
			(can_id & CAN_EFF_FLAG) ?
				(can_id & CAN_EFF_MASK) :
				(can_id & CAN_SFF_MASK),
			length);
	}

	for (i = 0; i < length && used < sizeof(xcan->tx_line); i++)
		used += scnprintf(
			xcan->tx_line + used,
			sizeof(xcan->tx_line) - used,
			" %02X", data[i]);
	if (used < sizeof(xcan->tx_line))
		used += scnprintf(
			xcan->tx_line + used,
			sizeof(xcan->tx_line) - used, "\r\n");

	if (used >= sizeof(xcan->tx_line)) {
		spin_lock_irqsave(&xcan->tx_lock, flags);
		xcan->tx_pending = false;
		spin_unlock_irqrestore(&xcan->tx_lock, flags);
		netdev->stats.tx_dropped++;
		dev_kfree_skb(skb);
		return NETDEV_TX_OK;
	}
	xcan->tx_length = used;

	netif_stop_queue(netdev);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	frame_length = can_skb_get_frame_len(skb);
	ret = can_put_echo_skb(skb, netdev, 0, frame_length);
	if (ret)
		goto err_pending;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
	ret = can_put_echo_skb(skb, netdev, 0);
	if (ret)
		goto err_pending;
#else
	can_put_echo_skb(skb, netdev, 0);
#endif

	schedule_work(&xcan->tx_work);
	return NETDEV_TX_OK;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
err_pending:
	spin_lock_irqsave(&xcan->tx_lock, flags);
	xcan->tx_pending = false;
	spin_unlock_irqrestore(&xcan->tx_lock, flags);
	netdev->stats.tx_dropped++;
	netif_wake_queue(netdev);
	return NETDEV_TX_OK;
#endif
}

static int xilume_can_configure_timing(struct xilume_can *xcan)
{
	const struct can_bittiming *bt = &xcan->can.bittiming;
	const struct can_bittiming *dbt = &xcan->can.data_bittiming;
	char command[160];
	u32 data_bitrate;
	u32 data_sample_point;
	u32 data_sjw;
	const char *ssp;
	int length;

	if (!bt->bitrate)
		return -EINVAL;

	if ((xcan->can.ctrlmode & CAN_CTRLMODE_FD) && dbt->bitrate) {
		data_bitrate = dbt->bitrate;
		data_sample_point = dbt->sample_point;
		data_sjw = dbt->sjw;
		ssp = "AUTO";
	} else {
		/* The data phase is unused by Classical CAN. */
		data_bitrate = 2000000U;
		data_sample_point = 750U;
		data_sjw = 1U;
		ssp = "0";
	}

	length = scnprintf(
		command, sizeof(command),
		"SET_TIMING CAN%u %u %u.%u %u %u %u.%u %u %s\r\n",
		xcan->channel + 1,
		bt->bitrate, bt->sample_point / 10,
		bt->sample_point % 10, bt->sjw,
		data_bitrate, data_sample_point / 10,
		data_sample_point % 10, data_sjw, ssp);

	return xilume_can_request(
		xcan, XILUME_CAN_RESPONSE_TIMING, command, length);
}

static int xilume_can_open(struct net_device *netdev)
{
	struct xilume_can *xcan = netdev_priv(netdev);
	int ret;

	ret = open_candev(netdev);
	if (ret)
		return ret;

	ret = xilume_can_configure_timing(xcan);
	if (ret) {
		netdev_err(
			netdev,
			"CAN%u timing rejected by firmware: %d\n",
			xcan->channel + 1, ret);
		close_candev(netdev);
		return ret;
	}

	xcan->can.state = CAN_STATE_ERROR_ACTIVE;
	xcan->bec.txerr = 0;
	xcan->bec.rxerr = 0;
	netif_start_queue(netdev);
	return 0;
}

static int xilume_can_stop(struct net_device *netdev)
{
	struct xilume_can *xcan = netdev_priv(netdev);

	netif_stop_queue(netdev);
	xcan->can.state = CAN_STATE_STOPPED;
	xilume_can_abort_request(xcan, -ECANCELED);
	cancel_work_sync(&xcan->tx_work);
	xilume_can_finish_echo(xcan, false);
	close_candev(netdev);
	return 0;
}

static int xilume_can_set_mode(struct net_device *netdev,
			       enum can_mode mode)
{
	struct xilume_can *xcan = netdev_priv(netdev);
	char command[32];
	int length;
	int ret;

	if (mode != CAN_MODE_START)
		return -EOPNOTSUPP;

	length = scnprintf(
		command, sizeof(command), "RESET_CAN CAN%u\r\n",
		xcan->channel + 1);
	ret = xilume_can_request(
		xcan, XILUME_CAN_RESPONSE_RESET, command, length);
	if (!ret) {
		xcan->can.state = CAN_STATE_ERROR_ACTIVE;
		xcan->can.can_stats.restarts++;
		xcan->bec.txerr = 0;
		xcan->bec.rxerr = 0;
		netif_wake_queue(netdev);
	}
	return ret;
}

static int xilume_can_get_berr_counter(const struct net_device *netdev,
				       struct can_berr_counter *bec)
{
	const struct xilume_can *xcan = netdev_priv(netdev);

	*bec = xcan->bec;
	return 0;
}

static const struct net_device_ops xilume_can_netdev_ops = {
	.ndo_open = xilume_can_open,
	.ndo_stop = xilume_can_stop,
	.ndo_start_xmit = xilume_can_start_xmit,
	.ndo_change_mtu = can_change_mtu,
};

static int xilume_register_can(struct xilume_device *xdev,
			       unsigned int channel)
{
	struct net_device *netdev;
	struct xilume_can *xcan;
	int ret;

	netdev = alloc_candev(sizeof(*xcan), 1);
	if (!netdev)
		return -ENOMEM;

	xcan = netdev_priv(netdev);
	xcan->netdev = netdev;
	xcan->xdev = xdev;
	xcan->channel = channel;
	spin_lock_init(&xcan->rx_lock);
	mutex_init(&xcan->request_mutex);
	spin_lock_init(&xcan->response_lock);
	init_completion(&xcan->response_done);
	spin_lock_init(&xcan->tx_lock);
	INIT_WORK(&xcan->tx_work, xilume_can_tx_worker);

	xcan->can.clock.freq = XILUME_CAN_CLOCK_HZ;
	xcan->can.bittiming_const = &xilume_nominal_bittiming_const;
	xcan->can.data_bittiming_const = &xilume_data_bittiming_const;
	xcan->can.ctrlmode_supported = CAN_CTRLMODE_FD;
	xcan->can.do_set_mode = xilume_can_set_mode;
	xcan->can.do_get_berr_counter = xilume_can_get_berr_counter;
	xcan->can.state = CAN_STATE_STOPPED;

	netdev->netdev_ops = &xilume_can_netdev_ops;
	netdev->flags |= IFF_ECHO;
	/* Keep the kernel-assigned can%d name to avoid global name conflicts. */
	netdev->dev_port = channel;
	SET_NETDEV_DEV(netdev, &xdev->interface->dev);

	xdev->cans[channel] = xcan;
	ret = register_candev(netdev);
	if (ret) {
		dev_err(
			&xdev->interface->dev,
			"could not register Xilume CAN FD %u: %d\n",
			channel + 1, ret);
		xdev->cans[channel] = NULL;
		free_candev(netdev);
		return ret;
	}

	dev_info(
		&xdev->interface->dev,
		"Xilume CAN FD %u registered as %s\n",
		channel + 1, netdev->name);
	return 0;
}

static void xilume_unregister_can(struct xilume_device *xdev,
				   unsigned int channel)
{
	struct xilume_can *xcan = xdev->cans[channel];

	if (!xcan)
		return;

	xdev->cans[channel] = NULL;
	xilume_can_abort_request(xcan, -ENODEV);
	unregister_candev(xcan->netdev);
	cancel_work_sync(&xcan->tx_work);
	free_candev(xcan->netdev);
}

static void xilume_handle_ack(struct xilume_device *xdev,
			      const struct xilume_frame_header *header,
			      const u8 *payload, size_t payload_length)
{
	unsigned long flags;
	u8 request_type;

	if (payload_length < 2)
		return;
	request_type = payload[0];

	spin_lock_irqsave(&xdev->ack_lock, flags);
	if (!xdev->ack_pending ||
	    header->channel != xdev->ack_channel ||
	    request_type != xdev->ack_request_type) {
		spin_unlock_irqrestore(&xdev->ack_lock, flags);
		return;
	}

	if (header->type == XILUME_FRAME_ACK && payload_length >= 4) {
		xdev->ack_status = payload[1];
		xdev->ack_error = 0;
		xdev->ack_transferred =
			(u16)payload[2] | ((u16)payload[3] << 8);
	} else {
		xdev->ack_status = 0xff;
		xdev->ack_error = payload[1];
		xdev->ack_transferred = 0;
	}
	spin_unlock_irqrestore(&xdev->ack_lock, flags);
	complete(&xdev->ack_done);
}

static void xilume_dispatch_frame(struct xilume_device *xdev,
				  const struct xilume_frame_header *header,
				  const u8 *payload, size_t payload_length)
{
	if (header->type == XILUME_FRAME_HELLO &&
	    header->channel == 0xff && header->flags == 0 &&
	    payload_length == 12 &&
	    payload[0] == XILUME_PROTOCOL_VERSION &&
	    payload[1] == XILUME_CHANNEL_COUNT &&
	    payload[2] == XILUME_CAN_COUNT &&
	    payload[3] == 0 &&
	    payload[6] == 1 &&
	    payload[7] == XILUME_MAX_PAYLOAD &&
	    (payload[11] & 0x03) == 0x03) {
		xdev->firmware_major = payload[8];
		xdev->firmware_minor = payload[9];
		xdev->firmware_patch = payload[10];
		WRITE_ONCE(xdev->hello_valid, true);
		complete_all(&xdev->hello_done);
		return;
	}

	if (header->type == XILUME_FRAME_ACK ||
	    header->type == XILUME_FRAME_ERROR) {
		xilume_handle_ack(xdev, header, payload, payload_length);
		return;
	}

	if (header->type == XILUME_FRAME_DATA &&
	    header->channel < XILUME_CAN_COUNT &&
	    payload_length) {
		struct xilume_can *xcan = xdev->cans[header->channel];

		if (xcan)
			xilume_can_feed_stream(xcan, payload, payload_length);
		return;
	}
}

static void xilume_parse_usb_block(struct xilume_device *xdev,
				   const u8 *buffer, size_t length)
{
	size_t offset = 0;

	while (length - offset >= XILUME_FRAME_HEADER_SIZE) {
		struct xilume_frame_header header;
		size_t payload_length;
		size_t frame_length;

		memcpy(&header, buffer + offset, sizeof(header));
		if (header.magic0 != XILUME_MAGIC_0 ||
		    header.magic1 != XILUME_MAGIC_1 ||
		    header.version != XILUME_PROTOCOL_VERSION) {
			offset++;
			atomic64_inc(&xdev->rx_protocol_errors);
			continue;
		}

		payload_length = le16_to_cpu(header.length);
		frame_length = sizeof(header) + payload_length;
		if (payload_length > XILUME_MAX_PAYLOAD ||
		    frame_length > length - offset) {
			atomic64_inc(&xdev->rx_protocol_errors);
			return;
		}

		xilume_dispatch_frame(
			xdev, &header, buffer + offset + sizeof(header),
			payload_length);
		atomic64_inc(&xdev->rx_frames);
		offset += frame_length;
	}

	if (offset != length)
		atomic64_inc(&xdev->rx_protocol_errors);
}

static void xilume_rx_complete(struct urb *urb)
{
	struct xilume_rx_slot *slot = urb->context;
	struct xilume_device *xdev = slot->xdev;
	int ret;

	if (urb->status == 0 && urb->actual_length)
		xilume_parse_usb_block(xdev, slot->buffer,
				       urb->actual_length);
	else if (urb->status != -ENOENT &&
		 urb->status != -ECONNRESET &&
		 urb->status != -ESHUTDOWN) {
		atomic64_inc(&xdev->usb_errors);
		dev_warn_ratelimited(
			&xdev->interface->dev,
			"bulk IN completion error %d\n", urb->status);
	}

	if (READ_ONCE(xdev->disconnected))
		return;

	usb_anchor_urb(urb, &xdev->rx_anchor);
	ret = usb_submit_urb(urb, GFP_ATOMIC);
	if (ret) {
		usb_unanchor_urb(urb);
		atomic64_inc(&xdev->usb_errors);
		dev_warn_ratelimited(
			&xdev->interface->dev,
			"could not resubmit bulk IN URB: %d\n", ret);
	}
}

static int xilume_start_rx(struct xilume_device *xdev)
{
	unsigned int i;

	for (i = 0; i < XILUME_RX_URB_COUNT; i++) {
		struct xilume_rx_slot *slot = &xdev->rx[i];
		int ret;

		slot->xdev = xdev;
		slot->urb = usb_alloc_urb(0, GFP_KERNEL);
		if (!slot->urb)
			return -ENOMEM;
		slot->buffer = kmalloc(XILUME_USB_PACKET_SIZE, GFP_KERNEL);
		if (!slot->buffer)
			return -ENOMEM;

		usb_fill_bulk_urb(
			slot->urb, xdev->udev,
			usb_rcvbulkpipe(xdev->udev, xdev->bulk_in),
			slot->buffer, XILUME_USB_PACKET_SIZE,
			xilume_rx_complete, slot);
		usb_anchor_urb(slot->urb, &xdev->rx_anchor);
		ret = usb_submit_urb(slot->urb, GFP_KERNEL);
		if (ret) {
			usb_unanchor_urb(slot->urb);
			return ret;
		}
	}

	return 0;
}

static void xilume_free_rx(struct xilume_device *xdev)
{
	unsigned int i;

	for (i = 0; i < XILUME_RX_URB_COUNT; i++) {
		usb_free_urb(xdev->rx[i].urb);
		kfree(xdev->rx[i].buffer);
		xdev->rx[i].urb = NULL;
		xdev->rx[i].buffer = NULL;
	}
}

static void xilume_stop_rx(struct xilume_device *xdev)
{
	unsigned int i;

	/*
	 * Kill every URB directly so disconnect also waits for a completion
	 * callback that has already been removed from the anchor.
	 */
	for (i = 0; i < XILUME_RX_URB_COUNT; i++) {
		if (xdev->rx[i].urb)
			usb_kill_urb(xdev->rx[i].urb);
	}
}

static ssize_t xilume_firmware_show(struct device *dev,
				    struct device_attribute *attr, char *buf)
{
	struct usb_interface *interface = to_usb_interface(dev);
	struct xilume_device *xdev = usb_get_intfdata(interface);

	(void)attr;
	if (!xdev || READ_ONCE(xdev->disconnected))
		return -ENODEV;
	return scnprintf(buf, PAGE_SIZE, "%u.%u.%u\n",
			 xdev->firmware_major, xdev->firmware_minor,
			 xdev->firmware_patch);
}
static DEVICE_ATTR_RO(xilume_firmware);

static ssize_t xilume_hello_topology_show(struct device *dev,
					  struct device_attribute *attr,
					  char *buf)
{
	struct usb_interface *interface = to_usb_interface(dev);
	struct xilume_device *xdev = usb_get_intfdata(interface);

	(void)attr;
	if (!xdev || !READ_ONCE(xdev->hello_valid) ||
	    READ_ONCE(xdev->disconnected))
		return -ENODEV;
	return scnprintf(buf, PAGE_SIZE, "2 2 0\n");
}
static DEVICE_ATTR_RO(xilume_hello_topology);

static void xilume_complete_waiters(struct xilume_device *xdev)
{
	unsigned long flags;
	unsigned int channel;

	spin_lock_irqsave(&xdev->ack_lock, flags);
	if (xdev->ack_pending) {
		xdev->ack_status = 0xff;
		xdev->ack_error = 0xff;
		xdev->ack_transferred = 0;
	}
	spin_unlock_irqrestore(&xdev->ack_lock, flags);
	complete_all(&xdev->ack_done);
	complete_all(&xdev->hello_done);

	for (channel = 0; channel < XILUME_CAN_COUNT; channel++) {
		if (xdev->cans[channel])
			xilume_can_abort_request(
				xdev->cans[channel], -ENODEV);
	}
}

static void xilume_teardown(struct xilume_device *xdev)
{
	unsigned int channel;

	if (READ_ONCE(xdev->disconnected))
		return;
	WRITE_ONCE(xdev->disconnected, true);

	if (xdev->topology_attr_created) {
		device_remove_file(&xdev->interface->dev,
				   &dev_attr_xilume_hello_topology);
		xdev->topology_attr_created = false;
	}
	if (xdev->firmware_attr_created) {
		device_remove_file(&xdev->interface->dev,
				   &dev_attr_xilume_firmware);
		xdev->firmware_attr_created = false;
	}
	usb_set_intfdata(xdev->interface, NULL);
	xilume_complete_waiters(xdev);
	xilume_stop_rx(xdev);

	for (channel = 0; channel < XILUME_CAN_COUNT; channel++)
		xilume_unregister_can(xdev, channel);

	xilume_free_rx(xdev);
	kref_put(&xdev->kref, xilume_device_release);
}

static int xilume_usb_probe(struct usb_interface *interface,
			    const struct usb_device_id *id)
{
	struct usb_host_interface *alt = interface->cur_altsetting;
	struct xilume_device *xdev;
	struct usb_endpoint_descriptor *endpoint;
	unsigned long waited;
	unsigned int i;
	u16 acknowledged;
	int ret;

	(void)id;
	if (alt->desc.bInterfaceNumber != XILUME_USB_INTERFACE ||
	    alt->desc.bNumEndpoints != 2)
		return -ENODEV;
	xdev = kzalloc(sizeof(*xdev), GFP_KERNEL);
	if (!xdev)
		return -ENOMEM;

	kref_init(&xdev->kref);
	xdev->udev = usb_get_dev(interface_to_usbdev(interface));
	xdev->interface = interface;
	xdev->tx_buffer = kmalloc(XILUME_USB_PACKET_SIZE, GFP_KERNEL);
	if (!xdev->tx_buffer) {
		ret = -ENOMEM;
		goto err_put;
	}
	mutex_init(&xdev->tx_mutex);
	spin_lock_init(&xdev->ack_lock);
	init_completion(&xdev->ack_done);
	init_completion(&xdev->hello_done);
	init_usb_anchor(&xdev->rx_anchor);

	for (i = 0; i < alt->desc.bNumEndpoints; i++) {
		endpoint = &alt->endpoint[i].desc;
		if (usb_endpoint_is_bulk_in(endpoint) &&
		    endpoint->bEndpointAddress == XILUME_USB_EP_IN &&
		    usb_endpoint_maxp(endpoint) == XILUME_USB_PACKET_SIZE)
			xdev->bulk_in = endpoint->bEndpointAddress;
		if (usb_endpoint_is_bulk_out(endpoint) &&
		    endpoint->bEndpointAddress == XILUME_USB_EP_OUT &&
		    usb_endpoint_maxp(endpoint) == XILUME_USB_PACKET_SIZE)
			xdev->bulk_out = endpoint->bEndpointAddress;
	}
	if (!xdev->bulk_in || !xdev->bulk_out) {
		ret = -ENODEV;
		goto err_put;
	}

	usb_set_intfdata(interface, xdev);
	ret = xilume_start_rx(xdev);
	if (ret)
		goto err_teardown;

	ret = xilume_send_frame(
		xdev, 0xff, XILUME_FRAME_HELLO, NULL, 0,
		false, &acknowledged);
	if (ret)
		goto err_teardown;

	waited = wait_for_completion_timeout(
		&xdev->hello_done,
		msecs_to_jiffies(XILUME_HELLO_TIMEOUT_MS));
	if (!waited || !READ_ONCE(xdev->hello_valid)) {
		dev_err(&interface->dev,
			"XILUME-MUX-V1 HELLO validation timed out\n");
		ret = -EPROTO;
		goto err_teardown;
	}

	ret = device_create_file(&interface->dev,
				 &dev_attr_xilume_firmware);
	if (ret)
		goto err_teardown;
	xdev->firmware_attr_created = true;
	ret = device_create_file(&interface->dev,
				 &dev_attr_xilume_hello_topology);
	if (ret)
		goto err_teardown;
	xdev->topology_attr_created = true;

	for (i = 0; i < XILUME_CAN_COUNT; i++) {
		ret = xilume_register_can(xdev, i);
		if (ret)
			goto err_teardown;
	}

	dev_info(
		&interface->dev,
		"Xilume XL1326-A ready: firmware %u.%u.%u, HELLO=2/2/0, 2 SocketCAN\n",
		xdev->firmware_major, xdev->firmware_minor,
		xdev->firmware_patch);
	return 0;

err_teardown:
	xilume_teardown(xdev);
	return ret;
err_put:
	kref_put(&xdev->kref, xilume_device_release);
	return ret;
}

static void xilume_usb_disconnect(struct usb_interface *interface)
{
	struct xilume_device *xdev = usb_get_intfdata(interface);

	if (!xdev)
		return;
	dev_info(&interface->dev, "Xilume XL1326-A disconnected\n");
	xilume_teardown(xdev);
}

static const struct usb_device_id xilume_usb_ids[] = {
	{ USB_DEVICE_AND_INTERFACE_INFO(
		XILUME_USB_VID, XILUME_USB_PID,
		USB_CLASS_VENDOR_SPEC, 0x00, 0x00) },
	{ }
};
MODULE_DEVICE_TABLE(usb, xilume_usb_ids);

static struct usb_driver xilume_usb_driver = {
	.name = XILUME_DRIVER_NAME,
	.probe = xilume_usb_probe,
	.disconnect = xilume_usb_disconnect,
	.id_table = xilume_usb_ids,
	.supports_autosuspend = 0,
};

static int __init xilume_init(void)
{
	int ret;

	BUILD_BUG_ON(sizeof(struct xilume_frame_header) !=
		     XILUME_FRAME_HEADER_SIZE);

	ret = usb_register(&xilume_usb_driver);
	if (ret)
		return ret;

	pr_info("%s: version %s loaded\n",
		XILUME_DRIVER_NAME, XILUME_DRIVER_VERSION);
	return 0;

}

static void __exit xilume_exit(void)
{
	usb_deregister(&xilume_usb_driver);
	pr_info("%s: unloaded\n", XILUME_DRIVER_NAME);
}

module_init(xilume_init);
module_exit(xilume_exit);

MODULE_AUTHOR("Xilume");
MODULE_DESCRIPTION("Xilume XL1326-A XILUME-MUX-V1 SocketCAN driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(XILUME_DRIVER_VERSION);
