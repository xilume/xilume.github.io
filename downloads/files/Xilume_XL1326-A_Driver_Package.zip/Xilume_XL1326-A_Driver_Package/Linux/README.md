# Xilume XL1326-A Linux Driver

Version 2.0.1

## System requirements

- Linux kernel 5.4 or later
- DKMS, compiler toolchain, and kernel headers

## Install

```bash
chmod +x install.sh uninstall.sh verify.sh
sudo ./install.sh
```

Reconnect the device after installation, then check the two SocketCAN
interfaces:

```bash
./verify.sh
```

## Remove

```bash
sudo ./uninstall.sh
```

## Support

Email echen070301@gmail.com with the product model and Linux version

---

# Xilume XL1326-A Linux 驱动

版本 2.0.1

## 系统要求

- Linux 5.4 或更新内核
- DKMS、编译工具与当前内核头文件

## 安装

```bash
chmod +x install.sh uninstall.sh verify.sh
sudo ./install.sh
```

安装完成后重新连接设备，再检查两路 SocketCAN 接口：

```bash
./verify.sh
```

## 卸载

```bash
sudo ./uninstall.sh
```

## 技术支持

请将产品型号与 Linux 版本发送至 echen070301@gmail.com
