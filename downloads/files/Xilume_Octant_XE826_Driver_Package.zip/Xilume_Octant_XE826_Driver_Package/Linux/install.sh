#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_NAME="xilume-8com"
PACKAGE_VERSION="1.2.3"
MODULE_NAME="xilume_8com"
KERNEL_VERSION="$(uname -r)"
KERNEL_BUILD="/lib/modules/${KERNEL_VERSION}/build"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="${SCRIPT_DIR}/driver"
DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-${PACKAGE_VERSION}"
OLD_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.0.0"
PREVIOUS_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.1.0"
TTY_ONLY_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.1.1"
SOCKETCAN_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.2.0"
FIXED_NAME_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.2.1"
DYNAMIC_NAME_DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-1.2.2"
UDEV_RULE="/etc/udev/rules.d/99-xilume-8com.rules"
DIRECT_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/updates/xilume"
DIRECT_MODULE="${DIRECT_MODULE_DIR}/${MODULE_NAME}.ko"
STALE_DKMS_MODULE="/lib/modules/${KERNEL_VERSION}/updates/dkms/${MODULE_NAME}.ko"

say() {
    printf '%s\n' "$*"
}

die() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

run_as_root() {
    if [[ "${EUID}" -eq 0 ]]; then
        return
    fi

    command -v sudo >/dev/null 2>&1 ||
        die "Run this installer as root or install sudo."
    exec sudo bash "$0" "$@"
}

install_build_dependencies() {
    say "Installing build dependencies for kernel ${KERNEL_VERSION}..."

    if command -v apt-get >/dev/null 2>&1; then
        export DEBIAN_FRONTEND=noninteractive
        apt-get update
        apt-get install -y \
            build-essential dkms "linux-headers-${KERNEL_VERSION}" \
            openssl mokutil xz-utils zstd gzip
    elif command -v dnf >/dev/null 2>&1; then
        dnf install -y \
            gcc make dkms "kernel-devel-${KERNEL_VERSION}" \
            openssl mokutil xz zstd gzip
    elif command -v yum >/dev/null 2>&1; then
        yum install -y \
            gcc make dkms "kernel-devel-${KERNEL_VERSION}" \
            openssl mokutil xz zstd gzip
    elif command -v zypper >/dev/null 2>&1; then
        zypper --non-interactive install \
            gcc make dkms kernel-default-devel \
            openssl mokutil xz zstd gzip
    elif command -v pacman >/dev/null 2>&1; then
        pacman --noconfirm -S --needed \
            base-devel dkms linux-headers openssl mokutil xz zstd gzip
    else
        die "Install gcc, make, DKMS, and headers matching uname -r."
    fi
}

remove_registered_version() {
    local version="$1"

    if command -v dkms >/dev/null 2>&1 &&
       dkms status -m "${PACKAGE_NAME}" -v "${version}" 2>/dev/null |
       grep -q .; then
        dkms remove -m "${PACKAGE_NAME}" -v "${version}" --all
    fi
}

sign_installed_module() {
    local module_path="$1"
    local private_key="$2"
    local certificate="$3"
    local sign_file="${KERNEL_BUILD}/scripts/sign-file"
    local sign_tmp
    local plain_module

    [[ -x "${sign_file}" ]] ||
        die "Kernel sign-file helper is unavailable."

    case "${module_path}" in
        *.ko)
            "${sign_file}" sha256 \
                "${private_key}" "${certificate}" "${module_path}"
            ;;
        *.ko.xz|*.ko.gz|*.ko.zst)
            sign_tmp="$(mktemp -d /tmp/xilume-8com-sign.XXXXXX)"
            plain_module="${sign_tmp}/${MODULE_NAME}.ko"

            case "${module_path}" in
                *.ko.xz)
                    command -v xz >/dev/null 2>&1 ||
                        die "xz is required to sign this module."
                    xz -dc -- "${module_path}" > "${plain_module}"
                    ;;
                *.ko.gz)
                    command -v gzip >/dev/null 2>&1 ||
                        die "gzip is required to sign this module."
                    gzip -dc -- "${module_path}" > "${plain_module}"
                    ;;
                *.ko.zst)
                    command -v zstd >/dev/null 2>&1 ||
                        die "zstd is required to sign this module."
                    zstd -q -d -c -- "${module_path}" > "${plain_module}"
                    ;;
            esac

            "${sign_file}" sha256 \
                "${private_key}" "${certificate}" "${plain_module}"

            case "${module_path}" in
                *.ko.xz)
                    xz -C crc32 -f -- "${plain_module}"
                    install -m 0644 "${plain_module}.xz" "${module_path}"
                    ;;
                *.ko.gz)
                    gzip -n -f -- "${plain_module}"
                    install -m 0644 "${plain_module}.gz" "${module_path}"
                    ;;
                *.ko.zst)
                    zstd -q -19 -f -- "${plain_module}" \
                        -o "${plain_module}.zst"
                    install -m 0644 "${plain_module}.zst" "${module_path}"
                    ;;
            esac
            rm -rf -- "${sign_tmp}"
            ;;
        *)
            die "Unsupported module format: ${module_path}"
            ;;
    esac
}

handle_secure_boot() {
    local module_path
    local secure_boot_state
    local key_dir="/var/lib/xilume-8hub/mok"
    local key_private="${key_dir}/Xilume-8HUB-MOK.key"
    local key_der="${key_dir}/Xilume-8HUB-MOK.der"

    command -v mokutil >/dev/null 2>&1 ||
        die "The module could not be loaded. Install mokutil or disable Secure Boot."
    command -v openssl >/dev/null 2>&1 ||
        die "The module could not be loaded. Install openssl or disable Secure Boot."

    secure_boot_state="$(LC_ALL=C mokutil --sb-state 2>/dev/null || true)"
    [[ "${secure_boot_state}" == *enabled* ]] ||
        die "The module could not be loaded. Check: journalctl -k -n 100"

    module_path="$(modinfo -n "${MODULE_NAME}" 2>/dev/null || true)"
    [[ -n "${module_path}" && -f "${module_path}" ]] ||
        die "The installed module file could not be located."

    install -d -m 0700 "${key_dir}"
    if [[ ! -f "${key_private}" || ! -f "${key_der}" ]]; then
        say "Secure Boot is enabled. Creating a local module signing key..."
        openssl req -new -x509 -newkey rsa:3072 \
            -keyout "${key_private}" \
            -outform DER -out "${key_der}" \
            -nodes -days 3650 \
            -subj "/CN=Xilume 8HUB Local Module/"
        chmod 0600 "${key_private}"
        chmod 0644 "${key_der}"
    fi

    sign_installed_module \
        "${module_path}" "${key_private}" "${key_der}"
    depmod -a "${KERNEL_VERSION}"

    if mokutil --test-key "${key_der}" >/dev/null 2>&1; then
        modprobe "${MODULE_NAME}" ||
            die "The signed module still could not be loaded."
        return
    fi

    say
    say "The driver is built and signed, but the key must be enrolled."
    say "Set a one-time password when prompted."
    say "After reboot, select: Enroll MOK -> Continue -> Yes."
    mokutil --import "${key_der}"
    say
    say "Reboot, enroll the key, then run install.sh again."
    exit 2
}

run_as_root "$@"

[[ -f "${SOURCE_DIR}/xilume_8com.c" ]] ||
    die "Missing driver/xilume_8com.c"
[[ -f "${SOURCE_DIR}/Makefile" ]] ||
    die "Missing driver/Makefile"
[[ -f "${SOURCE_DIR}/dkms.conf" ]] ||
    die "Missing driver/dkms.conf"
[[ -f "${SCRIPT_DIR}/99-xilume-8com.rules" ]] ||
    die "Missing 99-xilume-8com.rules"

if [[ ! -d "${KERNEL_BUILD}" ]] ||
   ! command -v make >/dev/null 2>&1 ||
   ! command -v gcc >/dev/null 2>&1; then
    install_build_dependencies
fi

[[ -d "${KERNEL_BUILD}" ]] ||
    die "Headers for kernel ${KERNEL_VERSION} are not installed."
command -v make >/dev/null 2>&1 || die "make is not installed."
command -v gcc >/dev/null 2>&1 || die "gcc is not installed."

if lsmod | awk '{print $1}' | grep -qx "${MODULE_NAME}"; then
    if command -v ip >/dev/null 2>&1; then
        for NET_PATH in /sys/class/net/*; do
            [[ -e "${NET_PATH}/device/driver/module" ]] || continue
            if [[ "$(readlink -f -- "${NET_PATH}/device/driver/module")" == "/sys/module/${MODULE_NAME}" ]]; then
                ip link set dev "$(basename -- "${NET_PATH}")" down || true
            fi
        done
    fi
    modprobe -r "${MODULE_NAME}" ||
        die "Close ttyXilume ports, bring CAN interfaces down, unplug the Hub, and run install.sh again."
fi

if command -v dkms >/dev/null 2>&1; then
    remove_registered_version "1.0.0"
    remove_registered_version "1.1.0"
    remove_registered_version "1.1.1"
    remove_registered_version "1.2.0"
    remove_registered_version "1.2.1"
    remove_registered_version "1.2.2"
    remove_registered_version "${PACKAGE_VERSION}"

    rm -rf -- "${OLD_DKMS_SOURCE}" "${PREVIOUS_DKMS_SOURCE}" \
        "${TTY_ONLY_DKMS_SOURCE}" "${SOCKETCAN_DKMS_SOURCE}" \
        "${FIXED_NAME_DKMS_SOURCE}" "${DYNAMIC_NAME_DKMS_SOURCE}" \
        "${DKMS_SOURCE}"
    install -d -m 0755 "${DKMS_SOURCE}"
    install -m 0644 "${SOURCE_DIR}/xilume_8com.c" \
        "${DKMS_SOURCE}/xilume_8com.c"
    install -m 0644 "${SOURCE_DIR}/Makefile" \
        "${DKMS_SOURCE}/Makefile"
    install -m 0644 "${SOURCE_DIR}/dkms.conf" \
        "${DKMS_SOURCE}/dkms.conf"

    say "Building and installing the Xilume 8HUB DKMS module..."
    dkms add -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}"
    if ! dkms build -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}" \
        -k "${KERNEL_VERSION}"; then
        DKMS_BUILD_LOG="/var/lib/dkms/${PACKAGE_NAME}/${PACKAGE_VERSION}/build/make.log"
        if [[ -f "${DKMS_BUILD_LOG}" ]]; then
            say
            say "DKMS compiler log:"
            tail -n 160 -- "${DKMS_BUILD_LOG}" || true
        fi
        die "DKMS build failed for kernel ${KERNEL_VERSION}."
    fi
    dkms install -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}" \
        -k "${KERNEL_VERSION}" --force

    # The DKMS build succeeded; an older direct build must not shadow it.
    rm -f -- "${DIRECT_MODULE}" "${DIRECT_MODULE}.xz" \
        "${DIRECT_MODULE}.gz" "${DIRECT_MODULE}.zst"
else
    BUILD_TMP="$(mktemp -d /tmp/xilume-8com-build.XXXXXX)"
    cleanup_build() {
        rm -rf -- "${BUILD_TMP}"
    }
    trap cleanup_build EXIT

    say "DKMS is unavailable. Building for the current kernel only..."
    install -m 0644 "${SOURCE_DIR}/xilume_8com.c" \
        "${BUILD_TMP}/xilume_8com.c"
    install -m 0644 "${SOURCE_DIR}/Makefile" \
        "${BUILD_TMP}/Makefile"
    make -C "${KERNEL_BUILD}" M="${BUILD_TMP}" modules

    # Only remove the previous direct module after the replacement built.
    rm -f -- "${DIRECT_MODULE}" "${DIRECT_MODULE}.xz" \
        "${DIRECT_MODULE}.gz" "${DIRECT_MODULE}.zst" \
        "${STALE_DKMS_MODULE}" "${STALE_DKMS_MODULE}.xz" \
        "${STALE_DKMS_MODULE}.gz" "${STALE_DKMS_MODULE}.zst"
    install -d -m 0755 "${DIRECT_MODULE_DIR}"
    install -m 0644 "${BUILD_TMP}/${MODULE_NAME}.ko" \
        "${DIRECT_MODULE}"
fi

install -m 0644 "${SCRIPT_DIR}/99-xilume-8com.rules" "${UDEV_RULE}"
depmod -a "${KERNEL_VERSION}"

if ! modprobe "${MODULE_NAME}"; then
    handle_secure_boot
fi
LOADED_VERSION="$(cat -- "/sys/module/${MODULE_NAME}/version" 2>/dev/null || true)"
if [[ -z "${LOADED_VERSION}" ]]; then
    LOADED_VERSION="$(modinfo -F version "${MODULE_NAME}" 2>/dev/null || true)"
fi
[[ "${LOADED_VERSION}" == "${PACKAGE_VERSION}" ]] ||
    die "Loaded module version ${LOADED_VERSION:-unknown}; expected ${PACKAGE_VERSION}."
modprobe can_raw 2>/dev/null || true

if command -v udevadm >/dev/null 2>&1; then
    udevadm control --reload-rules
    udevadm trigger --subsystem-match=tty || true
    udevadm trigger --subsystem-match=net || true
fi

if getent group dialout >/dev/null 2>&1 &&
   [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
    usermod -a -G dialout "${SUDO_USER}"
fi

say
say "Xilume 8HUB official Linux driver installed."
say "Reconnect the Hub, then run: ${SCRIPT_DIR}/verify.sh"
say "CAN interface names are assigned dynamically; verify.sh shows CAN1 and CAN2."
say "Expected serial interfaces: /dev/xilume/serial1 through serial6"
if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
    say "Log out and back in if the dialout group was added."
fi
