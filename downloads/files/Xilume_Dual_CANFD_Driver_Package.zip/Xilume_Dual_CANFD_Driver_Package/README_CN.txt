Xilume 双通道 CAN FD 驱动包
发布日期：2026-09-04

Windows
运行 Windows/Xilume_Dual_CANFD_Windows_Driver_V1.0.0.1.exe，然后连接设备

Linux
打开 Linux 文件夹并按照 README.md 完成安装
2.0.2 修复主机重启或 USB 重新枚举后偶发无法绑定的问题

包含版本
Windows 驱动 1.0.0.1
Linux 驱动 2.0.2

技术支持
echen070301@gmail.com
