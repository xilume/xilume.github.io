#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_NAME="xilume-dualcanfd"
PACKAGE_VERSION="2.0.1"
MODULE_NAME="xilume_dualcanfd"
LEGACY_MODULE="xilume_canfd"
LEGACY_PACKAGE="xilume-canfd"
KERNEL_VERSION="$(uname -r)"
KERNEL_BUILD="/lib/modules/${KERNEL_VERSION}/build"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="${SCRIPT_DIR}/driver"
DKMS_SOURCE="/usr/src/${PACKAGE_NAME}-${PACKAGE_VERSION}"
DIRECT_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/updates/xilume"
DIRECT_MODULE="${DIRECT_MODULE_DIR}/${MODULE_NAME}.ko"
STALE_DKMS_MODULE="/lib/modules/${KERNEL_VERSION}/updates/dkms/${MODULE_NAME}.ko"

say() { printf '%s\n' "$*"; }
die() { printf 'Error: %s\n' "$*" >&2; exit 1; }

run_as_root() {
    [[ "${EUID}" -eq 0 ]] && return
    command -v sudo >/dev/null 2>&1 ||
        die "Run this installer as root or install sudo."
    exec sudo bash "$0" "$@"
}

install_build_dependencies() {
    say "Installing build dependencies for kernel ${KERNEL_VERSION}..."
    if command -v apt-get >/dev/null 2>&1; then
        export DEBIAN_FRONTEND=noninteractive
        apt-get update
        apt-get install -y build-essential dkms \
            "linux-headers-${KERNEL_VERSION}" openssl mokutil \
            xz-utils zstd gzip
    elif command -v dnf >/dev/null 2>&1; then
        dnf install -y gcc make dkms "kernel-devel-${KERNEL_VERSION}" \
            openssl mokutil xz zstd gzip
    elif command -v yum >/dev/null 2>&1; then
        yum install -y gcc make dkms "kernel-devel-${KERNEL_VERSION}" \
            openssl mokutil xz zstd gzip
    elif command -v zypper >/dev/null 2>&1; then
        zypper --non-interactive install gcc make dkms \
            kernel-default-devel openssl mokutil xz zstd gzip
    elif command -v pacman >/dev/null 2>&1; then
        pacman --noconfirm -S --needed base-devel dkms linux-headers \
            openssl mokutil xz zstd gzip
    else
        die "Install gcc, make, DKMS, and headers matching uname -r."
    fi
}

bring_module_can_down() {
    local target_module="$1"
    local net_path
    command -v ip >/dev/null 2>&1 || return 0
    for net_path in /sys/class/net/*; do
        [[ -e "${net_path}/device/driver/module" ]] || continue
        if [[ "$(readlink -f -- "${net_path}/device/driver/module")" == "/sys/module/${target_module}" ]]; then
            ip link set dev "$(basename -- "${net_path}")" down || true
        fi
    done
}

unload_if_loaded() {
    local target_module="$1"
    if lsmod | awk '{print $1}' | grep -qx "${target_module}"; then
        bring_module_can_down "${target_module}"
        modprobe -r "${target_module}" ||
            die "Unplug XL1326-A, close CAN users, and rerun install.sh."
    fi
}

remove_dkms_package_all_versions() {
    local package="$1"
    local version
    command -v dkms >/dev/null 2>&1 || return 0
    while IFS= read -r version; do
        [[ -n "${version}" ]] || continue
        dkms remove -m "${package}" -v "${version}" --all || true
    done < <(
        dkms status -m "${package}" 2>/dev/null |
        sed -n "s#^${package}/\([^,[:space:]]*\).*#\1#p" |
        sort -u
    )
}

remove_legacy_dual_module_file() {
    local legacy_path

    command -v modinfo >/dev/null 2>&1 || return 0
    legacy_path="$(modinfo -n "${LEGACY_MODULE}" 2>/dev/null || true)"
    case "${legacy_path}" in
        "/lib/modules/${KERNEL_VERSION}/"*"/${LEGACY_MODULE}.ko"|\
        "/lib/modules/${KERNEL_VERSION}/"*"/${LEGACY_MODULE}.ko.xz"|\
        "/lib/modules/${KERNEL_VERSION}/"*"/${LEGACY_MODULE}.ko.gz"|\
        "/lib/modules/${KERNEL_VERSION}/"*"/${LEGACY_MODULE}.ko.zst")
            say "Removing old XL1326-A module file: ${legacy_path}"
            rm -f -- "${legacy_path}"
            ;;
        "")
            ;;
        *)
            die "Refusing to remove unexpected legacy module path: ${legacy_path}"
            ;;
    esac
}

sign_installed_module() {
    local module_path="$1"
    local private_key="$2"
    local certificate="$3"
    local sign_file="${KERNEL_BUILD}/scripts/sign-file"
    [[ -x "${sign_file}" ]] || die "Kernel sign-file helper is unavailable."
    [[ "${module_path}" == *.ko ]] ||
        die "Compressed module signing is not supported by this installer."
    "${sign_file}" sha256 "${private_key}" "${certificate}" "${module_path}"
}

handle_secure_boot() {
    local module_path
    local secure_boot_state
    local key_dir="/var/lib/xilume-dualcanfd/mok"
    local key_private="${key_dir}/Xilume-DualCANFD-MOK.key"
    local key_der="${key_dir}/Xilume-DualCANFD-MOK.der"

    command -v mokutil >/dev/null 2>&1 ||
        die "Module load failed; install mokutil or inspect journalctl -k."
    command -v openssl >/dev/null 2>&1 ||
        die "Module load failed; install openssl or inspect journalctl -k."
    secure_boot_state="$(LC_ALL=C mokutil --sb-state 2>/dev/null || true)"
    [[ "${secure_boot_state}" == *enabled* ]] ||
        die "Module load failed; inspect journalctl -k -n 100."

    module_path="$(modinfo -n "${MODULE_NAME}" 2>/dev/null || true)"
    [[ -n "${module_path}" && -f "${module_path}" ]] ||
        die "Installed module file was not found."
    install -d -m 0700 "${key_dir}"
    if [[ ! -f "${key_private}" || ! -f "${key_der}" ]]; then
        openssl req -new -x509 -newkey rsa:3072 \
            -keyout "${key_private}" -outform DER -out "${key_der}" \
            -nodes -days 3650 -subj "/CN=Xilume DualCANFD Local Module/"
        chmod 0600 "${key_private}"
        chmod 0644 "${key_der}"
    fi
    sign_installed_module "${module_path}" "${key_private}" "${key_der}"
    depmod -a "${KERNEL_VERSION}"
    if mokutil --test-key "${key_der}" >/dev/null 2>&1; then
        modprobe "${MODULE_NAME}" || die "Signed module still could not load."
        return
    fi
    say "Import the MOK key when prompted, reboot, enroll it, then rerun install.sh."
    mokutil --import "${key_der}"
    exit 2
}

run_as_root "$@"

[[ -f "${SOURCE_DIR}/xilume_dualcanfd.c" ]] ||
    die "Missing driver/xilume_dualcanfd.c"
[[ -f "${SOURCE_DIR}/Makefile" ]] || die "Missing driver/Makefile"
[[ -f "${SOURCE_DIR}/dkms.conf" ]] || die "Missing driver/dkms.conf"

if [[ ! -d "${KERNEL_BUILD}" ]] ||
   ! command -v make >/dev/null 2>&1 ||
   ! command -v gcc >/dev/null 2>&1; then
    install_build_dependencies
fi
[[ -d "${KERNEL_BUILD}" ]] ||
    die "Headers for kernel ${KERNEL_VERSION} are not installed."

# A previously distributed unified xilume_8com build may also advertise
# PID5742 and win the interface race.  Never unload/replace it silently,
# because it may be serving an eight-port device.  Stop with an explicit
# migration instruction instead.
if command -v modinfo >/dev/null 2>&1 &&
   modinfo -F alias xilume_8com 2>/dev/null |
   grep -Eqi 'v0*2e3c.*p0*5742'; then
    die "Installed xilume_8com also claims PID5742. Install xilume_8com 1.2.3 without PID5742 support first, then rerun; this installer will not touch that module."
fi

# Only XL1326-A modules are touched.  The shared xilume_8com
# package/module is intentionally never removed or unloaded here.
unload_if_loaded "${MODULE_NAME}"
unload_if_loaded "${LEGACY_MODULE}"
remove_dkms_package_all_versions "${PACKAGE_NAME}"
remove_dkms_package_all_versions "${LEGACY_PACKAGE}"
remove_legacy_dual_module_file

if command -v dkms >/dev/null 2>&1; then
    rm -rf -- "${DKMS_SOURCE}"
    install -d -m 0755 "${DKMS_SOURCE}"
    install -m 0644 "${SOURCE_DIR}/xilume_dualcanfd.c" \
        "${DKMS_SOURCE}/xilume_dualcanfd.c"
    install -m 0644 "${SOURCE_DIR}/Makefile" "${DKMS_SOURCE}/Makefile"
    install -m 0644 "${SOURCE_DIR}/dkms.conf" "${DKMS_SOURCE}/dkms.conf"
    say "Building and installing ${MODULE_NAME} ${PACKAGE_VERSION} with DKMS..."
    dkms add -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}"
    if ! dkms build -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}" \
        -k "${KERNEL_VERSION}"; then
        BUILD_LOG="/var/lib/dkms/${PACKAGE_NAME}/${PACKAGE_VERSION}/build/make.log"
        [[ -f "${BUILD_LOG}" ]] && tail -n 160 -- "${BUILD_LOG}" || true
        die "DKMS build failed for kernel ${KERNEL_VERSION}."
    fi
    dkms install -m "${PACKAGE_NAME}" -v "${PACKAGE_VERSION}" \
        -k "${KERNEL_VERSION}" --force
    rm -f -- "${DIRECT_MODULE}" "${DIRECT_MODULE}.xz" \
        "${DIRECT_MODULE}.gz" "${DIRECT_MODULE}.zst"
else
    BUILD_TMP="$(mktemp -d /tmp/xilume-dualcanfd-build.XXXXXX)"
    trap 'rm -rf -- "${BUILD_TMP}"' EXIT
    install -m 0644 "${SOURCE_DIR}/xilume_dualcanfd.c" \
        "${BUILD_TMP}/xilume_dualcanfd.c"
    install -m 0644 "${SOURCE_DIR}/Makefile" "${BUILD_TMP}/Makefile"
    make -C "${KERNEL_BUILD}" M="${BUILD_TMP}" modules
    install -d -m 0755 "${DIRECT_MODULE_DIR}"
    install -m 0644 "${BUILD_TMP}/${MODULE_NAME}.ko" "${DIRECT_MODULE}"
    rm -f -- "${STALE_DKMS_MODULE}" "${STALE_DKMS_MODULE}.xz" \
        "${STALE_DKMS_MODULE}.gz" "${STALE_DKMS_MODULE}.zst"
fi

depmod -a "${KERNEL_VERSION}"
if ! modprobe "${MODULE_NAME}"; then
    handle_secure_boot
fi
LOADED_VERSION="$(cat -- "/sys/module/${MODULE_NAME}/version" 2>/dev/null || true)"
[[ "${LOADED_VERSION}" == "${PACKAGE_VERSION}" ]] ||
    die "Loaded ${MODULE_NAME} version ${LOADED_VERSION:-unknown}; expected ${PACKAGE_VERSION}."
modprobe can_raw 2>/dev/null || true

say
say "Xilume XL1326-A Linux driver ${PACKAGE_VERSION} installed."
say "Reconnect the PID 5742 device, then run: ${SCRIPT_DIR}/verify.sh"
say "The driver creates exactly two dynamically named SocketCAN interfaces."
