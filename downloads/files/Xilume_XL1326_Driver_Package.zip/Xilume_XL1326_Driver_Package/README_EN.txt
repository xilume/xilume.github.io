Xilume XL1326 Driver Package
Release date: 2026-08-26

Product configuration
Windows exposes eight Xilume COM ports: ports 1 and 2 are CAN/CAN FD, and ports 3 through 8 are serial ports
Linux provides two SocketCAN interfaces and six stable serial paths

Windows
Run Windows/Xilume_XL1326_Windows_Driver_V7.1.9.0.exe, then connect XL1326
Windows assigns the actual COM numbers automatically

Linux
Open the Linux folder and follow README.md

Included versions
Windows driver 7.1.9.0
Linux driver 1.2.3

Support
echen070301@gmail.com
