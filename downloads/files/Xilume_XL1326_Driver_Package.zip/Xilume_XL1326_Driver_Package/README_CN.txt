Xilume XL1326 驱动包
发布日期：2026-08-26

产品配置
Windows 显示 8 个 Xilume COM 端口，其中 1、2 为 CAN/CAN FD，3 至 8 为串行端口
Linux 提供 2 路 SocketCAN 接口和 6 个稳定串行路径

Windows
运行 Windows/Xilume_XL1326_Windows_Driver_V7.1.9.0.exe，然后连接 XL1326
Windows 会自动分配具体 COM 编号

Linux
打开 Linux 文件夹并按照 README.md 完成安装

包含版本
Windows 驱动 7.1.9.0
Linux 驱动 1.2.3

技术支持
echen070301@gmail.com
