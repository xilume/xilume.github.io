Xilume XL1326-A 驱动包
发布日期：2026-08-26

产品配置
Windows 显示 2 个 Xilume CAN/CAN FD COM 端口
Linux 提供 2 路 SocketCAN 接口
XL1326-A 不提供六路串行接口

Windows
运行 Windows/Xilume_XL1326-A_Windows_Driver_V1.0.0.1.exe，然后连接 XL1326-A
Windows 会自动分配具体 COM 编号
设备管理器示例见 Windows/XL1326-A_Device_Manager_Result.png

Linux
打开 Linux 文件夹并按照 README.md 完成安装

包含版本
Windows 驱动 1.0.0.1
Linux 驱动 2.0.1

技术支持
echen070301@gmail.com
