Xilume Dual CAN FD Driver Package
Release date: 2026-09-04

Windows
Run Windows/Xilume_Dual_CANFD_Windows_Driver_V1.0.0.1.exe, then connect the device

Linux
Open the Linux folder and follow README.md
Version 2.0.2 fixes occasional binding failures after a host reboot or USB re-enumeration

Included versions
Windows driver 1.0.0.1
Linux driver 2.0.2

Support
echen070301@gmail.com
