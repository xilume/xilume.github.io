# Xilume DualCANFD 独立 Linux SocketCAN 驱动

模块版本：`2.0.2`；兼容固件版本：`7.3.0` 和 `7.3.1`。

`2.0.2` 修复主机重启或 USB 重新枚举后 MI_04 偶发无法绑定的问题：
probe 阶段会同步排空旧 MUX 数据并有限重试 HELLO；运行期间遇到
`-EPROTO/-EILSEQ/-ETIME` 等 USB 错误时使用延迟退避，不再在完成回调中
高速重复提交 URB。安装器会自动清理旧版 DKMS 记录。

这个驱动只绑定本工程的 DualCANFD Linux MUX 接口：

- USB VID:PID：`2e3c:5742`
- interface class/subclass/protocol：`ff/00/00`
- interface number：`4`
- Bulk OUT：`0x05`，Bulk IN：`0x85`
- 协议：`XILUME-MUX-V1`，64 byte packet
- HELLO 必须严格返回：2 个逻辑通道、2 个 CAN、0 个串口、1 个 transport、56 byte payload
- 只创建两个 SocketCAN 网络接口，不创建 `ttyXilume*`

它与 8HUB 的 `xilume_8com` 完全独立；不会绑定 `2e3c:5740`。

## 安装

```bash
chmod +x install.sh uninstall.sh verify.sh
sudo ./install.sh
```

安装脚本会先卸载会抢占 `2e3c:5742` 的旧 `xilume_canfd`，再用 DKMS
安装 `xilume_dualcanfd`。安装后拔插一次设备并运行：

```bash
./verify.sh
```

`verify.sh` 根据内核模块和 `dev_port` 识别实际接口名，不假定它们一定是
`can0`/`can1`。

## Classical CAN 示例

以下假设 `verify.sh` 显示 CAN1 为 `can0`，CAN2 为 `can1`：

```bash
sudo ip link set can0 down
sudo ip link set can1 down
sudo ip link set can0 type can bitrate 500000
sudo ip link set can1 type can bitrate 500000
sudo ip link set can0 up
sudo ip link set can1 up
candump can1 &
cansend can0 123#11223344
```

两路直连时要连接 CANH/CANH、CANL/CANL，并共地；总线两端各接
120 Ω。PB14 必须保持低电平，使收发器处于正常模式。

## CAN FD 示例（500 kbit/s + 5 Mbit/s）

```bash
sudo ip link set can0 down
sudo ip link set can1 down
sudo ip link set can0 type can bitrate 500000 dbitrate 5000000 fd on
sudo ip link set can1 type can bitrate 500000 dbitrate 5000000 fd on
sudo ip link set can0 up
sudo ip link set can1 up
candump can1 &
cansend can0 123##11122334455667788
```

仲裁速率、数据速率、FD/BRS 配置必须与对端一致。

## 通道映射

| MUX logical channel | 固件绑定通道 | MCU CAN | 引脚 |
|---:|---:|---|---|
| 0 | 1 | CAN1 | PB8/PB9 |
| 1 | 2 | CAN2 | PB12/PB13 |

驱动在 logical 0/1 上发送文本；固件只在内部做 `logical + 1`，所以不存在
CAN1/CAN2 的 off-by-one 映射。

## 协议边界

为与已量产验证的 8HUB V7.2.1 CAN 文本协议保持一致，本版不表示 RTR，
也不能区分 ID 数值不大于 `0x7ff` 的扩展帧和标准帧。驱动会明确拒绝这
两种无法无损表达的帧。常规 Classical CAN、CAN FD 和 BRS 均支持。

## 卸载

```bash
sudo ./uninstall.sh
```

## 重要固件说明

交付目录不包含旧 HEX/OBJ/MAP。必须在 Keil 中执行 **Rebuild all target
files**；新 build log 必须出现 `mux_can.c`，且不得出现 `linux_can.c`。
